#pragma once

#include <iostream>
#include "bidirectionaliterator.h"
#include "linkedlistiterator.h"



template<class type>
class LinkedList
{
public:
	struct ListNode
	{
	public:
		type m_Value;
		ListNode* m_Next;
		ListNode* m_Previous;

		ListNode()
		{
			m_Next = nullptr;
			m_Previous = nullptr;
		}

		ListNode(type data)
		{
			m_Value = data;
			m_Next = nullptr;
			m_Previous = nullptr;
		}
	};
	CONST_ITERATOR_DECLARATION(BidirectionalConst_Iterator_Base, type, ListNode);
	ITERATOR_DECLARATION(BidirectionalIterator_Base, type, ListNode);
	CONST_REVERSE_ITERATOR_DECLARATION(BidirectionalConst_Reverse_Iterator_Base, type, ListNode);
	REVERSE_ITERATOR_DECLARATION(BidirectionalReverse_Iterator_Base, type, ListNode);


	LinkedList()
	{
		m_Head = nullptr;
	}

	LinkedList(const LinkedList<type>& other)
	{
		Clear();

		ListNode* node = other.m_Head;
		m_Head = nullptr;
		while (node != nullptr)
		{
			AddBack(node->m_Value);
			node = node->m_Next;
		}


	}

	LinkedList(std::initializer_list<type> list)
	{
		Clear();
		for (type x : list)
		{
			this->AddBack(x);
		}
	}

	~LinkedList()
	{
		Clear();
	}

	iterator begin() { return iterator(m_Head); }
	const_iterator cbegin() const { return const_iterator(&m_Head); }

	reverse_iterator rbegin()
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size-1; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return reverse_iterator(current_Node);

	}

	const_reverse_iterator crbegin()
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size - 1; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return const_reverse_iterator(current_Node);

	}

	iterator end()
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return iterator(current_Node);
	}
	reverse_iterator rend() { return reverse_iterator(m_Head->m_Previous); }
	const_reverse_iterator crend() { return const_reverse_iterator(m_Head->m_Previous); }
	iterator LastElement()
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size - 1; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return iterator(current_Node);
	}

	ListNode* tail()
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size - 1; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return current_Node;
	}
	const_iterator cend() const
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i <= m_size; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return const_iterator(&current_Node);
	}

	const_iterator CLastElement()
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size - 1; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return const_iterator(current_Node);
	}


	LinkedList& operator=(LinkedList other)
	{
		Clear();
		ListNode* node = other.m_Head;
		m_Head = nullptr;
		while (node != nullptr)
		{
			AddBack(node->m_Value);
			node = node->m_Next;
		}
		m_size = other.m_size;
		m_capacity = other.m_capacity;
		return *this;
	}

	void OutPutList()
	{

		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size; i++)
		{
			std::cout << current_Node->m_Value << std::endl;
			current_Node = current_Node->m_Next;
		}
	}

	type& Get(int index)
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < index; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return current_Node->m_Value;
	}

	ListNode* GetNode(int index)
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < index; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return current_Node;
	}
	void AddBack(type data)
	{
		if (m_Head == nullptr)
		{
			m_Head = new ListNode(data);
			m_capacity++;
			m_size++;
		}
		else
		{
			ListNode* current_Node = m_Head;
			while (current_Node->m_Next != nullptr)
			{
				current_Node = current_Node->m_Next;
			}
			ListNode* new_Node = new ListNode(data);
			m_capacity++;
			m_size++;
			current_Node->m_Next = new_Node;
			new_Node->m_Previous = current_Node;
		}
	}

	void AddFront(type data)
	{
		if (m_Head == nullptr)
		{
			m_Head = new ListNode(data);
			m_size++;
			m_capacity++;
		}
		else
		{
			ListNode* current_Node = new ListNode(data);
			current_Node->m_Next = m_Head;
			m_Head->m_Previous = current_Node;
			m_Head = current_Node;
			m_size++;
			m_capacity++;

		}
	}
	void Resize(unsigned int size)
	{
		if (size > static_cast<unsigned int>(m_size))
		{
			unsigned int endsize = size - m_size;
			m_capacity = size;
			for (unsigned int i = 0; i < endsize; i++)
			{
				ListNode* current_Node = m_Head;
				while (current_Node->m_Next != nullptr)
				{
					current_Node = current_Node->m_Next;
				}
				ListNode* new_Node = new ListNode();
				current_Node->m_Next = new_Node;
				new_Node->m_Previous = current_Node;
			}
		}
		else
		{
			unsigned removeamount = m_size - size;

			for (unsigned int i = 0; i < removeamount; i++)
			{
				PopBack();
			}

		}
	}

	void Resize(unsigned int size, type data)
	{
		if (size > m_size)
		{
			unsigned int endsize = size - m_size;
			m_capacity = size;
			for (unsigned int i = 0; i < endsize; i++)
			{
				AddBack(data);
			}
		}
		else
		{
			int removeamount = m_size - size;
			m_capacity = size;
			for (unsigned int i = 0; i < removeamount; i++)
			{
				PopBack();
			}
		}
	}
	bool IsEmpty() { return m_size == 0; }
	void PopFront()
	{
		m_Head = m_Head->m_Next;
		m_Head->m_Previous = nullptr;
		m_capacity--;
		m_size--;
	}
	void PopBack()
	{
		ListNode* current_Node = m_Head;
		if (current_Node == nullptr)
		{
			return;
		}
		else if (current_Node->m_Next == nullptr)
		{
			delete current_Node;
			m_Head = nullptr;
			m_capacity--;
			m_size--;
			return;
		}
		while (current_Node->m_Next != nullptr && current_Node->m_Next->m_Next != nullptr)
		{

			current_Node = current_Node->m_Next;
		}
		delete current_Node->m_Next;
		m_capacity--;
		m_size--;
		current_Node->m_Next = nullptr;
	}

	int size() { return m_size; }
	int Size() { return m_size; }
	int GetCapacity() { return m_capacity; }

	void Clear()
	{
		if (m_size != 0)
		{
			ListNode* current_Node = m_Head;
			m_size = 0;
			m_capacity = 0;
			while (current_Node != nullptr)
			{
				current_Node = current_Node->m_Next;
				delete m_Head;
				m_Head = current_Node;
			}
		}
	}

	void insert(int index, type data)
	{
		ListNode* current_Node = m_Head;
		if (index <= m_size)
		{
			if (index > 0)
			{
				for (int i = 0; i < index - 1; i++)
				{
					current_Node = current_Node->m_Next;
				}

				ListNode* new_Node = new ListNode(data);
				new_Node->m_Next = current_Node->m_Next;
				new_Node->m_Previous = current_Node;
				current_Node->m_Next = new_Node;
				new_Node->m_Next->m_Previous = new_Node;
				m_capacity++;
				m_size++;
			}
			else if (index == 0)
			{
				ListNode* new_Node = new ListNode(data);
				new_Node->m_Next = m_Head;
				m_Head->m_Previous = new_Node;
				m_Head = new_Node;
				m_capacity++;
				m_size++;
			}

		}
	}

	void Remove(int index)
	{
		if (index <= m_size)
		{
			ListNode* current_Node = m_Head;
			ListNode* old_Node = nullptr;
			if (index > 0)
			{
				for (int i = 0; i < index - 1; i++)
				{
					current_Node = current_Node->m_Next;
				}
				old_Node = current_Node->m_Next;
				current_Node->m_Next = current_Node->m_Next->m_Next;
				current_Node->m_Next->m_Previous = current_Node;
				delete old_Node;
				m_capacity--;
				m_size--;
			}
			else if (index == 0)
			{
				current_Node = m_Head;
				m_Head = m_Head->m_Next;
				m_Head->m_Previous = nullptr;
				delete current_Node;
				m_capacity--;
				m_size--;
			}
		}
	}
	void insert(iterator it, type data)
	{
		ListNode* current_Node = m_Head;

		if (it != begin())
		{
			for (auto i = ++begin(); i != it; i++)
			{
				current_Node = current_Node->m_Next;
			}

			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = current_Node->m_Next;
			new_Node->m_Previous = current_Node;
			current_Node->m_Next = new_Node;
			if (new_Node->m_Next != nullptr)
			{
				new_Node->m_Next->m_Previous = new_Node;
			}
			m_capacity++;
			m_size++;
		}
		else
		{
			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = m_Head;
			m_Head->m_Previous = new_Node;
			m_Head = new_Node;
			m_capacity++;
			m_size++;
		}
	}

	void insert(const_iterator it, type data)
	{
		ListNode* current_Node = m_Head;

		if (it != cbegin())
		{
			for (auto i = ++cbegin(); i != it; i++)
			{
				current_Node = current_Node->m_Next;
			}

			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = current_Node->m_Next;
			new_Node->m_Previous = current_Node->m_Previous;
			current_Node->m_Next = new_Node;
			m_capacity++;
			m_size++;
		}
		else
		{
			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = m_Head;
			m_Head->m_Previous = new_Node;
			m_Head = new_Node;
			m_capacity++;
			m_size++;
		}
	}

	void insert(reverse_iterator it, type data)
	{
		ListNode* current_Node = tail();

		if (it != reverse_iterator(m_Head))
		{
			for (auto i = rbegin(); i != it; i++)
			{
				current_Node = current_Node->m_Previous;
			}

			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = current_Node->m_Next;
			new_Node->m_Previous = current_Node;
			current_Node->m_Next = new_Node;
			m_capacity++;
			m_size++;
		}
		else
		{
			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = m_Head;
			new_Node->m_Previous = nullptr;
			m_Head = new_Node;
			m_capacity++;
			m_size++;
		}
	}

	void insert(const_reverse_iterator it, type data)
	{
		ListNode* current_Node = tail();

		if (it != m_Head)
		{
			for (auto i = crbegin(); i != it; i++)
			{
				current_Node = current_Node->m_Previous;
			}

			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = current_Node->m_Next;
			new_Node->m_Previous = current_Node;
			current_Node->m_Next = new_Node;
			m_capacity++;
			m_size++;
		}
		else
		{
			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = m_Head;
			m_Head = new_Node;
			m_capacity++;
			m_size++;
		}
	}
	void Remove(iterator it)
	{

		ListNode* current_Node = m_Head;

		if (it != begin())
		{
			for (auto i = ++begin(); i != it; i++)
			{
				current_Node = current_Node->m_Next;
			}
			ListNode* old_Node = current_Node->m_Next;
			current_Node->m_Next = current_Node->m_Next->m_Next;
			if (current_Node->m_Next != nullptr)
			{
				current_Node->m_Next->m_Previous = current_Node;
			}
			delete old_Node;
			m_capacity--;
			m_size--;
		}
		else
		{
			current_Node = m_Head;
			m_Head = m_Head->m_Next;
			m_Head->m_Previous = nullptr;
			delete current_Node;
			m_capacity--;
			m_size--;
		}

	}

	void Remove(reverse_iterator it)
	{

		ListNode* current_Node = tail();
		
		if (it != reverse_iterator(m_Head))
		{
			it = ++it;
			for (auto i = rbegin(); i != it; i++)
			{
				current_Node = current_Node->m_Previous;
			}
			ListNode* old_Node = current_Node->m_Next;
			current_Node->m_Next = current_Node->m_Next->m_Next;
			if (current_Node->m_Next != nullptr)
			{
				current_Node->m_Next->m_Previous = current_Node;
			}
			delete old_Node;
			m_capacity--;
			m_size--;
		}
		else
		{
			current_Node = m_Head;
			m_Head = m_Head->m_Next;
			m_Head->m_Previous = nullptr;
			delete current_Node;
			m_capacity--;
			m_size--;
		}

	}

	void Remove(const_reverse_iterator it)
	{

		ListNode* current_Node = tail();

		if (it != const_reverse_iterator(m_Head))
		{
			it = ++it;
			for (auto i = rbegin(); i != it; i++)
			{
				current_Node = current_Node->m_Previous;
			}
			ListNode* old_Node = current_Node->m_Next;
			current_Node->m_Next = current_Node->m_Next->m_Next;
			if (current_Node->m_Next != nullptr)
			{
				current_Node->m_Next->m_Previous = current_Node;
			}
			delete old_Node;
			m_capacity--;
			m_size--;
		}
		else
		{
			current_Node = m_Head;
			m_Head = m_Head->m_Next;
			m_Head->m_Previous = nullptr;
			delete current_Node;
			m_capacity--;
			m_size--;
		}

	}

	void Remove(const_iterator it)
	{

		ListNode* current_Node = m_Head;

		if (it != begin())
		{
			for (auto i = ++begin(); i != it; i++)
			{
				current_Node = current_Node->m_Next;
			}
			ListNode* old_Node = current_Node->m_Next;
			current_Node->m_Next = current_Node->m_Next->m_Next;
			if (current_Node->m_Next != nullptr)
			{
				current_Node->m_Next->m_Previous = current_Node;
			}
			delete old_Node;
			m_capacity--;
			m_size--;
		}
		else
		{
			current_Node = m_Head;
			m_Head = m_Head->m_Next;
			m_Head->m_Previous = nullptr;
			delete current_Node;
			m_capacity--;
			m_size--;
		}

	}

private:

	ListNode* m_Head;
	int m_size = 0;
	int m_capacity = 0;

};

