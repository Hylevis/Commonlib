#pragma once

#define CONST_ITERATOR_DECLARATION(Class, ValueType, ListNodeType) \
    struct const_iterator : public Class<ValueType, const_iterator, ListNodeType> \
    { \
        const_iterator(ListNodeType* ptr) \
            :Class < ValueType, const_iterator, ListNodeType>{ ptr } \
        { } \
    }

#define ITERATOR_DECLARATION(Class, ValueType, ListNodeType) \
    struct iterator : public Class<ValueType, iterator, ListNodeType> \
    { \
        iterator(ListNodeType* ptr) \
            :Class<ValueType, iterator, ListNodeType>{ ptr } \
        { } \
    }

#define CONST_REVERSE_ITERATOR_DECLARATION(Class, ValueType, ListNodeType) \
    struct const_reverse_iterator : public Class<ValueType, const_reverse_iterator, ListNodeType>\
    {\
    const_reverse_iterator(ListNodeType* ptr)\
        :Class < ValueType, const_reverse_iterator, ListNodeType>{ ptr }\
    { }\
    }

#define REVERSE_ITERATOR_DECLARATION(Class, ValueType, ListNodeType) \
    struct reverse_iterator : public Class<ValueType, reverse_iterator, ListNodeType>\
    {\
    reverse_iterator(ListNodeType* ptr)\
        :Class<ValueType, reverse_iterator, ListNodeType>{ ptr }\
    { }\
    }\

