#pragma once
#include<iostream>

#define CONST_ITERATOR_DECLARATION(Class, ValueType) \
    struct const_iterator : public Class<ValueType, const_iterator> \
    { \
        const_iterator(ValueType* ptr) \
            :Class < ValueType, const_iterator>{ ptr } \
        { } \
    }

#define ITERATOR_DECLARATION(Class, ValueType) \
    struct iterator : public Class<ValueType, iterator> \
    { \
        iterator(ValueType* ptr) \
            :Class<ValueType, iterator>{ ptr } \
        { } \
    }

#define CONST_REVERSE_ITERATOR_DECLARATION(Class, ValueType) \
    struct const_reverse_iterator : public Class<ValueType, const_reverse_iterator>\
    {\
    const_reverse_iterator(ValueType* ptr)\
        :Class < ValueType, const_reverse_iterator>{ ptr }\
    { }\
    }

#define REVERSE_ITERATOR_DECLARATION(Class, ValueType) \
    struct reverse_iterator : public Class<ValueType, reverse_iterator>\
    {\
    reverse_iterator(ValueType* ptr)\
        :Class<ValueType, reverse_iterator>{ ptr }\
    { }\
    }\


template <typename type,typename iterator_type>
struct RandomAccessConst_Iterator_Base
{
public:
    using iterator_category = std::random_access_iterator_tag;
    using difference_type = std::ptrdiff_t;
    using value_type = type;
    using pointer = type*;
    using reference = type&;



    RandomAccessConst_Iterator_Base(type* ptr)
        :m_ptr{ ptr }
    { }

    // Prefix (++it)
    iterator_type& operator++() { m_ptr++; return *static_cast<iterator_type*>(this); }

    // Postfix (it++)
    iterator_type operator++(int)
    {
        iterator_type tmp = *static_cast<iterator_type*>(this);
        ++(*this);
        return tmp;
    }

    // Prefix (--it)
    iterator_type& operator--() { m_ptr--; return *static_cast<iterator_type*>(this); }

    // Postfix (it--)
    iterator_type operator--(int)
    {
        iterator_type tmp = *static_cast<iterator_type*>(this);
        --(*this);
        return tmp;
    }

    bool operator==(const iterator_type& right) const { return *(this->m_ptr) == *(right.m_ptr); }
    bool operator!=(const iterator_type& right) const { return *(this->m_ptr) != *(right.m_ptr); }
    iterator_type operator+(difference_type right) const { return this->m_ptr + right; }
    iterator_type operator+=(difference_type right) { return this->m_ptr += right; }
    iterator_type operator-(difference_type right) const { return this->m_ptr - right; }
    difference_type operator-(const iterator_type right) const { return this->m_ptr - right.m_ptr; }
    iterator_type operator-=(difference_type right) { return this->m_ptr -= right; }
    bool operator<(const iterator_type& right) const { return *(this->m_ptr) < *(right.m_ptr); }
    bool operator>(const iterator_type& right) const { return *(this->m_ptr) > *(right.m_ptr); }
    bool operator<=(const iterator_type& right) const { return *(this->m_ptr) <= *(right.m_ptr); }
    bool operator>=(const iterator_type& right) const { return *(this->m_ptr) >= *(right.m_ptr); }
    
    const type& operator[](difference_type index) const { return *(this->m_ptr + index); }
    const type& operator*() const { return *m_ptr; }
    const type* operator->() { return m_ptr; }
protected:
    type* m_ptr;
};



template <typename type, typename iterator_type>
struct RandomAccessIterator_Base : public RandomAccessConst_Iterator_Base<type, iterator_type>
{
public:
    using difference_type = RandomAccessConst_Iterator_Base<type, iterator_type>::difference_type;

    RandomAccessIterator_Base(type* ptr)
        :RandomAccessConst_Iterator_Base<type, iterator_type>{ ptr }
    { }

    type& operator[](difference_type index) const { return *(this->m_ptr + index); }
    type& operator*() const { return *this->m_ptr; }
    type* operator->() { return this->m_ptr; }
};


template <typename type, typename iterator_type>
struct RandomAccessConst_Reverse_Iterator_Base
{
    using iterator_category = std::random_access_iterator_tag;
    using difference_type = std::ptrdiff_t;
    using value_type = type;
    using pointer = type*;
    using reference = type&;
    RandomAccessConst_Reverse_Iterator_Base(type* ptr)
        :m_ptr{ ptr }
    { }

    // Prefix (++it)
    iterator_type& operator++() { m_ptr--; return *static_cast<iterator_type*>(this); }

    // Postfix (it++)
    iterator_type operator++(int)
    {
        iterator_type tmp = *static_cast<iterator_type*>(this);
        ++(*this);
        return tmp;
    }

    // Prefix (--it)
    iterator_type& operator--() { m_ptr++; return *static_cast<iterator_type*>(this); }

    // Postfix (it--)
    iterator_type operator--(int)
    {
        iterator_type tmp = *static_cast<iterator_type*>(this);
        --(*this);
        return tmp;
    }

    bool operator==(const iterator_type& right) const { return this->m_ptr == right.m_ptr; }
    bool operator!=(const iterator_type& right) const { return this->m_ptr != right.m_ptr; }
    iterator_type operator-(difference_type right) const { return this->m_ptr + right; }
    iterator_type operator-=(difference_type right) { return this->m_ptr += right; }
    iterator_type operator+(difference_type right) const { return this->m_ptr - right; }
    difference_type operator+(const iterator_type right) const { return this->m_ptr - right.m_ptr; }
    iterator_type operator+=(difference_type right) { return this->m_ptr -= right; }
    bool operator<(const iterator_type& right) const { return *(this->m_ptr) < *(right.m_ptr); }
    bool operator>(const iterator_type& right) const { return *(this->m_ptr) > *(right.m_ptr); }
    bool operator<=(const iterator_type& right) const { return *(this->m_ptr) <= *(right.m_ptr); }
    bool operator>=(const iterator_type& right) const { return *(this->m_ptr) >= *(right.m_ptr); }
    const type& operator[](difference_type index) const { return *(this->m_ptr - index); }
    const type& operator*() const { return *m_ptr; }
    const type* operator->() { return m_ptr; }
protected:
    type* m_ptr;
};



template <typename type, typename iterator_type>
struct RandomAccessReverse_Iterator_Base : public RandomAccessConst_Reverse_Iterator_Base<type, iterator_type>
{
public:
    using difference_type = RandomAccessConst_Reverse_Iterator_Base<type, iterator_type>::difference_type;

    RandomAccessReverse_Iterator_Base(type* ptr)
        :RandomAccessConst_Reverse_Iterator_Base<type, iterator_type>{ ptr }
    { }

    type& operator[](difference_type index) const { return *(this->m_ptr - index); }
    type& operator*() const { return *this->m_ptr; }
    type* operator->() { return this->m_ptr; }
};