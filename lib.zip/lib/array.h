#pragma once
#include<iostream>
#include "randomaccessiterator.h"


// Instructions:
// - The Array class should be able to store any type of object (int, string, Particle*, etc)
//     - Lookup Template classes in C++ if you need a refresher on how to do this
// - The Array class should implement the interface provided below
//     - I've omitted the types from some of the methods on purpose. You need to fix this to make it support any type.
// - Your array should use a contiguous block of memory on the heap. If you don't know what that means, Google it.
// - Do not copy/paste solutions from the internet. You must implement everything yourself using the knowledge you find online.
//     - Example: Don't google "how to implement an array". Instead, look up how to do the specific parts you don't know. 
//                Such as "how to use template classes in c++" or "how to allocate memory on the heap in c++".
// - There should be no bugs or memory leaks!

// What is an Array?
// An Array is one of many data structures common in programming. It is typically implemented as a contiguous block of memory that 
// is allocated on the heap. Since it is unknown how many elements are expected to be stored in the Array, it must be flexible and
// able to adapt to the changing demands from the programmer. 
// 
// Since it would be very inefficient to reallocate the block of memory every time we add/remove something from the array, it is
// common to instead allocate more than is needed and to avoid resizing unless necessary; such as when asked for by the user 
// or because there is no longer space. However, it would be equally inefficient to allocate too much in advanced because we may
// end up never using it and wasting memory. 
//
// For example, we may default to an available space of 10 values. When adding our first element, we allocate enough memory for 10 values
// to be stored and use just the first slot in our block of memory. This means our "size" is 1 since size is equal to the number of 
// elements stored in the array, however, our "available space" is 9 because that is how many additional elements we can store before 
// needing to resize the array. Once we try to add an 11th element, we now need to resize our array, meaning we need to allocate
// a new block of memory that is bigger, transfer all of the contents to the new block, and deallocate the old block of memory.
// But how big should we resize our array to? There is no "right" answer to this, but typically we will just double the previous size.
// If we had a size of 10 values before, we would double it to 20. If we had 40, we would double to 80, etc.
//
// Unlike with Adding, we generally don't resize the array when removing elements. However, if you find that you want to shrink the
// allocated memory for the array, that is where the Resize method comes in! If you had space for 80 elements and called Resize(20),
// it would resize the array for only 20 elements instead. Any values stored in the old array past the first 20 slots would be lost.
//
// This is where Reserve and Resize can be really practical! If you know in advanced you will need 80 slots and your array starts off empty,
// you can reserve space for 80 elements before you add any. That way you only resize it once instead of potentially several times! 
// If we take the example of starting at 10 and doubling every time we run out (10 -> 20 -> 40 -> 80), we would have to resize 4 times!
// That makes Reserving for 80 at the beginning at least 3x more efficient (since we always have to allocate memory at least once)!
template <typename type>
class Array
{
    using uint = unsigned int;

    type* m_Array = nullptr;
    uint m_CurrentSize = 0;
    uint m_MaxSize = 0;
public:
    CONST_ITERATOR_DECLARATION(RandomAccessConst_Iterator_Base, type);
    ITERATOR_DECLARATION(RandomAccessIterator_Base, type);
    CONST_REVERSE_ITERATOR_DECLARATION(RandomAccessConst_Reverse_Iterator_Base, type);
    REVERSE_ITERATOR_DECLARATION(RandomAccessReverse_Iterator_Base, type);

  
    // Begin should return an iterator to the first element
    iterator begin() { return iterator(&m_Array[0]); }
    iterator LastElement() { return iterator(&m_Array[m_CurrentSize - 1]); }
    const_iterator cbegin() const { return const_iterator(&m_Array[0]); }
    reverse_iterator rbegin() { return reverse_iterator(&m_Array[m_CurrentSize - 1]); }
    const_reverse_iterator crbegin() const { return const_reverse_iterator(&m_Array[m_CurrentSize - 1]); }

    // End should return an iterator to the element one after the last. 
    // So if you have an array of 4 elements, you want to return the "5th" element (even though there is no 5th).
    iterator end() { return iterator(&m_Array[m_CurrentSize]); }
    const_iterator cend() const { return const_iterator(&m_Array[m_CurrentSize]); }
    reverse_iterator rend() { return reverse_iterator(&m_Array[-1]); }
    const_reverse_iterator crend() const { return const_reverse_iterator(&m_Array[m_CurrentSize - 1]); }

    Array()
    {
        m_Array = new type[10];
        m_CurrentSize = 0;
        m_MaxSize = 1;
    }

    // Implement the copy-constructor. How can you avoid duplicating code between the copy constructor and = operator?
    Array(const Array<type>& other)
    {

        m_Array = new type[other.size()];
        m_CurrentSize = 0;
        m_MaxSize = static_cast<uint>(other.size());
        for (size_t i = 0; i < other.Size(); i++)
        {
            this->Add(other[i]);
        }


    }

    // Implement the initializer_list constructor. This allows you to use this syntax: { 1, 2, 3, 4 } 
    Array(std::initializer_list<type> list)
    {
        m_Array = new type[list.size()];
        m_CurrentSize = 0;
        m_MaxSize = static_cast<uint>(list.size());
        for (type x : list)
        {
            this->Add(x);
        }
    }

    // Adds a value to the array. It doesn't matter where its added.
    void Add(const type& value)
    {
        if (m_CurrentSize == m_MaxSize)
        {
            Reserve(m_MaxSize * 2);
        }
        m_Array[m_CurrentSize] = value;
        m_CurrentSize++;
    }

    // Returns how many elements are stored in the array
    uint Size() const { return m_CurrentSize; }
    uint size() const { return m_CurrentSize; }

    // Gets the value stored at the specified index
// This is allowed to crash with an invalid index
    const type& GetAt(uint index) const { return m_Array[index]; }
    type& GetAt(uint index) { return m_Array[index]; }

    // Adds a value to the array if it doesn't already exists. It doesn't matter where its added.
    // Returns true if it successfully adds the value
    bool AddUnique(const type& value)
    {
        for (uint i = 0; i < m_CurrentSize; i++)
        {
            if (m_Array[i] == value)
            {
                return false;
            }
        }
        Add(value);
        return true;
    }

    // Inserts the value at the index. 
    // Returns true if it successfully adds the value
    bool Insert(const type& value, uint index)
    {
        this->Add(value);
        for (int i = this->m_CurrentSize - 1; i > index; i--)
        {
            std::swap(this->m_Array[i], this->m_Array[i - 1]);
        }
        return true;
    }

    // Inserts the value at the position of the iterator.
    // Returns a new iterator representing the next value to iterate from
    iterator Insert(const type& value, iterator it)
    {
        if (m_CurrentSize + 1 <= m_MaxSize)
        {
            this->Add(value);
            iterator itend = LastElement();
            for (iterator i = it; i != itend; ++i)
            {
                std::swap(*i, *itend);
            }
            return it++;
        }
        else
        {
            m_MaxSize = m_MaxSize * 2;
            type* temp = new type[m_MaxSize];
            iterator thisIt = iterator(&temp[0]);
            iterator returnIt = iterator(&temp[0]);
            for (iterator i = begin(); i != it; ++i)
            {
                *thisIt = *i;
                thisIt++;
                returnIt++;
            }
            *thisIt = value;
            thisIt++;
            returnIt++;
            for (iterator i = it; i != --end(); ++i)
            {
                *thisIt = *it;
                ++it;
                thisIt++;
            }
            delete[] m_Array;
            m_Array = temp;
            m_CurrentSize++;
            return returnIt;

        }
    }
    reverse_iterator Insert(const type& value, reverse_iterator it)
    {

        if (m_CurrentSize + 1 <= m_MaxSize)
        {

            this->Add(value);
            reverse_iterator itend = rbegin();
            for (reverse_iterator i = it; i != itend; --i)
            {
                std::swap(*i, *itend);
            }
            return it++;

        }
        else
        {
            m_MaxSize = m_MaxSize * 2;
            type* temp = new type[m_MaxSize];
            reverse_iterator thisIt = reverse_iterator(&temp[0]);
            reverse_iterator returnIt = reverse_iterator(&temp[0]);
            for (reverse_iterator i = --rend(); i != it; --i)
            {
                *thisIt = *i;
                thisIt--;
                returnIt--;
            }
            *thisIt = value;
            thisIt--;
            returnIt--;
            for (reverse_iterator i = it; i != --rbegin(); --i)
            {
                *thisIt = *it;
                --it;
                thisIt--;
            }
            delete[] m_Array;
            m_Array = temp;
            m_CurrentSize++;
            return returnIt;

        }

    }

    // Removes the value at the specified index. This must not crash with an invalid index!
    // Returns true if it removes something
    bool RemoveAt(uint index)
    {
        for (int i = index; i < m_CurrentSize - 1; i++)
        {
            std::swap(m_Array[i], m_Array[i + 1]);
        }

        if (m_CurrentSize != 0)
        {
            m_CurrentSize--;
            return true;
            //output_vector();
        }
        return false;
    }

    // Removes the value at the position of the iterator
    // Returns a new iterator representing the next value to iterate from
    iterator RemoveAt(iterator it)
    {

        iterator itend = LastElement();
        if (itend == it)
        {
            m_CurrentSize--;
            return end();
        }
        else
        {
            for (iterator i = itend; i != it; --i)
            {
                std::swap(*i, *it);
            }
            m_CurrentSize--;
            return it;
        }
    }
    reverse_iterator RemoveAt(reverse_iterator it)
    {

        reverse_iterator itend = rbegin();
        if (itend == it)
        {
            m_CurrentSize--;
            return ++itend;
        }
        else
        {
            for (reverse_iterator i = rbegin(); i != it; ++i)
            {
                std::swap(*i, *it);
            }
            m_CurrentSize--;
            return it;
        }
    }

    // Removes the first value matching the passed value
    // Returns true if it removes a value
    bool Remove(type value)
    {
        int index = -1;
        for (uint i = 0; i < m_CurrentSize; i++)
        {
            if (m_Array[i] == value)
            {
                index = i;
            }
        }

        return RemoveAt(index);
    }

    // Resizes the array to the specified size
    void Resize(uint newSize)
    {
        type* temp = new type[newSize];
        const uint minSize = std::min(newSize, m_CurrentSize);
        for (uint i = 0; i < minSize; i++)
        {
            temp[i] = m_Array[i];
        }
        delete[] m_Array;
        m_MaxSize = newSize;
        m_CurrentSize = minSize;

        m_Array = temp;
    }

    // Will resize the array if the array isn't large enough to hold 'size' number of elements
    void Reserve(uint size)
    {
        if (size > m_MaxSize)
        {
            Resize(size);
        }
    }
    // Returns true if the array is empty
    bool IsEmpty() const { return (m_CurrentSize == 0); }
    // Returns true if the specified index is valid
    bool IsValidIndex(uint index) const { return(index <= m_MaxSize && index >= 0); }

    // Returns how many elements can still be added to the array before it must resize itself
    uint GetAvailableSpace() const { return m_MaxSize - m_CurrentSize; }

    // Clears the array of elements
    void Clear() { m_CurrentSize = 0; }

    // Gets the value stored at the specified index (using normal array access, aka: myArray[i])
    // This is allowed to crash with an invalid index
    const type& operator[](uint index) const { return GetAt(index); }
    type& operator[](uint index) { return GetAt(index); }
    bool operator==(Array<type>& other)
    {
        if (m_CurrentSize == other.m_CurrentSize && m_MaxSize == other.m_MaxSize)
        {
            for (uint i = 0; i < m_CurrentSize; i++)
            {
                if (m_Array[i] != other[i])
                {
                    return false;
                }
            }
            return true;
        }
        return false;
    };
    // Copies an array into this one!
    Array<type>& operator=(const Array<type>& other)
    {
        if (this == &other)
            return *this;

        m_Array = new type[other.size()];
        m_CurrentSize = 0;
        m_MaxSize = static_cast<uint>(other.size());
        for (uint i = 0; i < other.Size(); i++)
        {
            this->Add(other[i]);
        }
        return *this;
    }

    ~Array()
    {
        delete[] m_Array;
        m_Array = nullptr;
    }
};