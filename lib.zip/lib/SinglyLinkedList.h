#pragma once
#include <iostream>
#include "forwarditerator.h"
#include "linkedlistiterator.h"




template<class type>
class SinglyLinkedList
{
public:



	struct ListNode
	{
	public:
		type m_Value;
		ListNode* m_Next;

		ListNode()
		{
			m_Next = nullptr;
		}

		ListNode(type data)
		{
			m_Value = data;
			m_Next = nullptr;
		}
	};
	CONST_ITERATOR_DECLARATION(ForwardConst_Iterator_Base, type, ListNode);
	ITERATOR_DECLARATION(ForwardIterator_Base, type, ListNode);
	
	SinglyLinkedList()
	{
		m_Head = nullptr;
	}

	SinglyLinkedList(const SinglyLinkedList& other)
	{
		ListNode* node = other.m_Head;
		m_Head = nullptr;
		while (node != nullptr)
		{
			AddBack(node->m_Value);
			node = node->m_Next;
		}


	}

	SinglyLinkedList(std::initializer_list<type> list)
	{
		for (type x : list)
		{
			this->AddBack(x);
		}
	}

	~SinglyLinkedList()
	{
		ListNode* current = m_Head;
		while (current != 0)
		{
			ListNode* next = current->m_Next;
			delete current;
			current = next;
		}
		m_Head = 0;
	}

	iterator begin() { return iterator(m_Head); }
	const_iterator cbegin() const { return const_iterator(&m_Head); }
	
	iterator end()
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return iterator(current_Node);
	}
	
	iterator LastElement()
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size-1; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return iterator(current_Node);
	}


	const_iterator cend() const
	{ 
		ListNode* current_Node = m_Head;
		for (int i = 0; i <= m_size; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return const_iterator(&current_Node);
	}

	const_iterator CLastElement()
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size - 1; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return const_iterator(current_Node);
	}
	
	
	SinglyLinkedList& operator=(SinglyLinkedList other)
	{
		ListNode* node = other.m_Head;
		m_Head = nullptr;
		while (node != nullptr)
		{
			AddBack(node->m_Value);
			node = node->m_Next;
		}
		m_size = other.m_size;
		m_capacity = other.m_capacity;
		return *this;
	}

	void OutPutList()
	{

		ListNode* current_Node = m_Head;
		for (int i = 0; i < m_size; i++)
		{
			std::cout << current_Node->m_Value << std::endl;
			current_Node = current_Node->m_Next;
		}
	}

	type& Get(int index)
	{
		ListNode* current_Node = m_Head;
		for (int i = 0; i < index; i++)
		{
			current_Node = current_Node->m_Next;
		}
		return current_Node->m_Value;
	}
	void AddBack(type data)
	{
		if (m_Head == nullptr)
		{
			m_Head = new ListNode(data);
			m_capacity++;
			m_size++;
		}
		else
		{
			ListNode* current_Node = m_Head;
			while (current_Node->m_Next != nullptr)
			{
				current_Node = current_Node->m_Next;
			}
			ListNode* new_Node = new ListNode(data);
			m_capacity++;
			m_size++;
			current_Node->m_Next = new_Node;
		}
	}

	void AddFront(type data)
	{
		if (m_Head == nullptr)
		{
			m_Head = new ListNode(data);
			m_size++;
			m_capacity++;
		}
		else
		{
			ListNode* current_Node = new ListNode(data);
			current_Node->m_Next = m_Head;
			m_Head = current_Node;
			m_size++;
			m_capacity++;
			
		}
	}
	void Resize(unsigned int size)
	{
		if (size > static_cast<unsigned int>(m_size))
		{
			unsigned int endsize = size - m_size;
			m_capacity = size;
			for (unsigned int i = 0; i < endsize; i++)
			{
				ListNode* current_Node = m_Head;
				while (current_Node->m_Next != nullptr)
				{
					current_Node = current_Node->m_Next;
				}
				ListNode* new_Node = new ListNode();
				current_Node->m_Next = new_Node;
			}
		}
		else
		{
			unsigned removeamount =  m_size - size;
			
			for (unsigned int i = 0; i < removeamount; i++)
			{
				PopBack();
			}

		}
	}

	void Resize(unsigned int size, type data)
	{
		if (size > m_size)
		{
			unsigned int endsize = size - m_size;
			m_capacity = size;
			for (unsigned int i = 0; i < endsize; i++)
			{
				AddBack(data);
			}
		}
		else
		{
			int removeamount = m_size - size;
			m_capacity = size;
			for (unsigned int i = 0; i < removeamount; i++)
			{
				PopBack();
			}
		}
	}
	bool IsEmpty() { return m_size == 0; }
	void PopFront()
	{
		m_Head = m_Head->m_Next;
		m_capacity--;
		m_size--;
	}
	void PopBack()
	{
		ListNode* current_Node = m_Head;
		if (current_Node == nullptr)
		{
			return;
		}
		else if (current_Node->m_Next == nullptr)
		{
			delete current_Node;
			m_Head = nullptr;
			m_capacity--;
			m_size--;
			return;
		}
		while (current_Node->m_Next != nullptr && current_Node->m_Next->m_Next != nullptr)
		{

			current_Node = current_Node->m_Next;
		}
		delete current_Node->m_Next;
		m_capacity--;
		m_size--;
		current_Node->m_Next = nullptr;
	}

	int size(){return m_size;}
	int Size() { return m_size; }
	int GetCapacity() { return m_capacity; }

	void Clear()
	{
		ListNode* current_Node = m_Head;
		m_size = 0;
		m_capacity = 0;
		while (current_Node != nullptr)
		{
			current_Node = current_Node->m_Next;
			delete m_Head;
			m_Head = current_Node;
		}
	}

	void insert(int index, type data)
	{
		ListNode* current_Node = m_Head;
		if (index <= m_size)
		{
			if (index > 0)
			{
				for (int i = 0; i < index - 1; i++)
				{
					current_Node = current_Node->m_Next;
				}

				ListNode* new_Node = new ListNode(data);
				new_Node->m_Next = current_Node->m_Next;
				current_Node->m_Next = new_Node;
				m_capacity++;
				m_size++;
			}
			else if (index == 0)
			{
				ListNode* new_Node = new ListNode(data);
				new_Node->m_Next = m_Head;
				m_Head = new_Node;
				m_capacity++;
				m_size++;
			}

		}
	}

	void Remove(int index)
	{
		if (index <= m_size)
		{
			ListNode* current_Node = m_Head;
			ListNode* old_Node = nullptr;
			if (index > 0)
			{
				for (int i = 0; i < index - 1; i++)
				{
					current_Node = current_Node->m_Next;
				}
				old_Node = current_Node->m_Next;
				current_Node->m_Next = current_Node->m_Next->m_Next;
				delete old_Node;
				m_capacity--;
				m_size--;
			}
			else if (index == 0)
			{
				current_Node = m_Head;
				m_Head = m_Head->m_Next;
				delete current_Node;
				m_capacity--;
				m_size--;
			}
		}
	}
	void insert(iterator it, type data)
	{
		ListNode* current_Node = m_Head;

		if (it != begin())
		{
			for (auto i = ++begin(); i != it; i++)
			{
				current_Node = current_Node->m_Next;
			}

			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = current_Node->m_Next;
			current_Node->m_Next = new_Node;
			m_capacity++;
			m_size++;
		}
		else
		{
			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = m_Head;
			m_Head = new_Node;
			m_capacity++;
			m_size++;
		}
	}



	void insert(const_iterator it, type data)
	{
		ListNode* current_Node = m_Head;

		if (it != begin())
		{
			for (auto i = ++begin(); i != it; i++)
			{
				current_Node = current_Node->m_Next;
			}

			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = current_Node->m_Next;
			current_Node->m_Next = new_Node;
			m_capacity++;
			m_size++;
		}
		else
		{
			ListNode* new_Node = new ListNode(data);
			new_Node->m_Next = m_Head;
			m_Head = new_Node;
			m_capacity++;
			m_size++;
		}
	}
	void Remove(iterator it)
	{

		ListNode* current_Node = m_Head;

		if (it != begin())
		{
			for (auto i = ++begin(); i != it; i++)
			{
				current_Node = current_Node->m_Next;
			}
			ListNode* old_Node = current_Node->m_Next;
			current_Node->m_Next = current_Node->m_Next->m_Next;
			delete old_Node;
			m_capacity--;
			m_size--;
		}
		else
		{
			current_Node = m_Head;
			m_Head = m_Head->m_Next;
			delete current_Node;
			m_capacity--;
			m_size--;
		}

	}

	void Remove(const_iterator it)
	{

		ListNode* current_Node = m_Head;

		if (it != begin())
		{
			for (auto i = ++begin(); i != it; i++)
			{
				current_Node = current_Node->m_Next;
			}
			ListNode* old_Node = current_Node->m_Next;
			current_Node->m_Next = current_Node->m_Next->m_Next;
			delete old_Node;
			m_capacity--;
			m_size--;
		}
		else
		{
			current_Node = m_Head;
			m_Head = m_Head->m_Next;
			delete current_Node;
			m_capacity--;
			m_size--;
		}

	}

private:

		ListNode* m_Head;
		int m_size = 0;
		int m_capacity = 0;

};

