#pragma once
#include <iostream>
#include <stack>
#include "BSTForwardIterator.h"



template<class type>
class AVLTree {
private:
    int m_Size = 0;
public:
    struct node
    {
        type data;
        node* left;
        node* right;
        node* parent;
        int height;

        node() = delete;

        node(type x, node* leftptr, node* rightptr, node* parentptr)
            :data(x)
            , left(leftptr)
            , right(rightptr)
            , parent(parentptr)
            , height(1)
        {
        }
        node(type x)
            :data(x)
            , left(nullptr)
            , right(nullptr)
            , parent(nullptr)
            , height(1)
        {
        }
    };

    struct Trunk
    {
        Trunk* prev;
        std::string str;

        Trunk(Trunk* prev, type str)
        {
            this->prev = prev;
            this->str = str;
        }
    };

private:

    node* root;



    // Calculate height
    int height(node* N)
    {
        if (N == nullptr)
        {
            return 0;
        }
        return N->height;
    }

    int max(int a, int b)
    {
        return (a > b) ? a : b;
    }

    node* rightRotate(node* y) 
    {
        node* x = y->left;
        node* T2 = x->right;
        x->right = y;
        y->left = T2;
        y->height = max(height(y->left),
            height(y->right)) + 1;
        x->height = max(height(x->left),
            height(x->right)) + 1;
        return x;
    }

    node* leftRotate(node* x)
    {
        node* y = x->right;
        node* T2 = y->left;
        y->left = x;
        x->right = T2;
        x->height = max(height(x->left),
            height(x->right)) + 1;
        y->height = max(height(y->left),
            height(y->right)) + 1;
        return y;
    }

    node* makeEmpty(node* t)
    {
        if (t == nullptr)
            return nullptr;
        {
            makeEmpty(t->left);
            makeEmpty(t->right);
            delete t;
        }
        m_Size = 0;
        return nullptr;
    }

    int getBalanceFactor(node* N)
    {
        if (N == nullptr)
        {
            return 0;
        }
        return height(N->left) - height(N->right);
    }

    node* Add(type x, node* t, node* parent)
    {
        if (t == nullptr)
        {
            t = new node(x, nullptr, nullptr, parent);
        }
        else if (x <= t->data)
        {
            t->left = Add(x, t->left, t);
        }
        else if (x > t->data)
        {
            t->right = Add(x, t->right, t);
        }
        else
        {
            return t;
        }

        t->height = 1 + max(height(t->left),
            height(t->right));
        int balanceFactor = getBalanceFactor(t);
        if (balanceFactor > 1) {
            if (x < t->left->data) {
                return rightRotate(t);
            }
            else if (x > t->left->data) {
                t->left = leftRotate(t->left);
                return rightRotate(t);
            }
        }
        if (balanceFactor < -1) {
            if (x > t->right->data) {
                return leftRotate(t);
            }
            else if (x < t->right->data) {
                t->right = rightRotate(t->right);
                return leftRotate(t);
            }
        }
        return t;
    }

    node* findMin(node* t)
    {
        if (t == nullptr)
            return nullptr;
        else if (t->left == nullptr)
            return t;
        else
            return findMin(t->left);
    }

    node* findMax(node* t)
    {
        if (t == nullptr)
            return nullptr;
        else if (t->right == nullptr)
            return t;
        else
            return findMax(t->right);
    }

    node* remove(const type& x, node* t)
    {
        node* temp;
        if (t == nullptr)
        {
            return nullptr;
        }
        else if (x < t->data)
        {
            t->left = remove(x, t->left);
        }
        else if (x > t->data)
        {
            t->right = remove(x, t->right);
        }
        else if (t->left && t->right)
        {
            temp = findMin(t->right);
            t->data = temp->data;
            t->right = remove(t->data, t->right);
        }
        else
        {
            temp = t;
            if (t->left == nullptr)
            {
                t = t->right;
            }
            else if (t->right == nullptr)
            {
                t = t->left;
            }
            delete temp;
        }

        if(t == nullptr)
            return t;
        t->height = 1 + max(height(t->left),
            height(t->right));
        int balanceFactor = getBalanceFactor(t);
        if (balanceFactor > 1) {
            if (getBalanceFactor(t->left) >= 0) {
                return rightRotate(t);
            }
            else {
                t->left = leftRotate(t->left);
                return rightRotate(t);
            }
        }
        if (balanceFactor < -1) {
            if (getBalanceFactor(t->right) <= 0) {
                return leftRotate(t);
            }
            else {
                t->right = rightRotate(t->right);
                return leftRotate(t);
            }
        }

        return t;
    }




    void inorder(node* t)
    {
        if (t == nullptr)
            return;
        inorder(t->left);
        std::cout << t->data << " ";
        inorder(t->right);
    }

    node* find(node* t, type x)
    {
        if (t == nullptr)
        {
            return nullptr;
        }
        else if (x < t->data)
        {
            return find(t->left, x);
        }
        else if (x > t->data)
        {
            return find(t->right, x);
        }
        else
        {
            return t;
        }
    }

    void clearTree(node* node)
    {
        if (node != nullptr) {
            clearTree(node->left);
            clearTree(node->right);
            delete(node);
        }
    }

    void preOrderTraversal(node* c)
    {
        if (c != nullptr)
        {
            this->Add(c->data);
            preOrderTraversal(c->left);
            preOrderTraversal(c->right);
        }
    }

public:
    CONST_ITERATOR_DECLARATION(BSTForwardConst_Iterator_Base, type, node);
    ITERATOR_DECLARATION(BSTForwardIterator_Base, type, node);

    AVLTree()
        : root(nullptr)
    {
    }

    AVLTree(std::initializer_list<type> list)
    {
        for (const type& x : list)
        {
            this->Add(x);
        }
    }

    AVLTree(const AVLTree& other)
    {

        if (this != &other)
        {
            Clear();
            node* c = other.root;
            preOrderTraversal(c);
        }
        m_Size = other.m_Size;
    }
    ~AVLTree()
    {
        root = makeEmpty(root);
    }

    void Add(const type& x) {
        root = Add(x, root, nullptr);
        m_Size++;
    }

    void remove(const type& x)
    {
        root = remove(x, root);
        m_Size--;
    }

    void display()
    {
        inorder(root);
        std::cout << std::endl;
    }

    bool Exists(type x)
    {
        root = find(root, x);
        return root != nullptr;

    }

    void Clear()
    {
        root = makeEmpty(root);
    }

    node* GetRoot() { return root; }

    int size() { return m_Size; }
    int Size() { return m_Size; }
    bool IsEmpty() { return m_Size == 0; }

    const_iterator const cbegin() { return const_iterator(findMin(root)); }
    const_iterator const cend() { return const_iterator(nullptr); }

    void showTrunks(Trunk* p)
    {
        if (p == nullptr) {
            return;
        }

        showTrunks(p->prev);
        std::cout << p->str;
    }

    void printTree(node* root, Trunk* prev, bool isLeft)
    {
        if (root == nullptr) {
            return;
        }

        std::string prev_str = "    ";
        Trunk* trunk = new Trunk(prev, prev_str);

        printTree(root->right, trunk, true);

        if (!prev) {
            trunk->str = "���";
        }
        else if (isLeft)
        {
            trunk->str = ".���";
            prev_str = "   |";
        }
        else {
            trunk->str = "`���";
            prev->str = prev_str;
        }

        showTrunks(trunk);
        std::cout << " " << root->data << std::endl;

        if (prev) {
            prev->str = prev_str;
        }
        trunk->str = "   |";

        printTree(root->left, trunk, false);
    }

    AVLTree& operator=(AVLTree& other)
    {
        if (this != &other)
        {
            Clear();
            node* c = other.root;
            preOrderTraversal(c);
        }
        return *this;
        m_Size = other.size();
    }

};