#pragma once
#include<iostream>
#include<stack>

#define CONST_ITERATOR_DECLARATION(Class, ValueType, ListNodeType) \
    struct const_iterator : public Class<ValueType, const_iterator, ListNodeType> \
    { \
        const_iterator(ListNodeType* ptr) \
            :Class < ValueType, const_iterator, ListNodeType>{ ptr } \
        { } \
    }

#define ITERATOR_DECLARATION(Class, ValueType, ListNodeType) \
    struct iterator : public Class<ValueType, iterator, ListNodeType> \
    { \
        iterator(ListNodeType* ptr) \
            :Class<ValueType, iterator, ListNodeType>{ ptr } \
        { } \
    }


template <typename type, typename iterator_type, typename list_node_type>
struct BSTForwardConst_Iterator_Base
{

public:

    using iterator_category = std::forward_iterator_tag;
    using difference_type = std::ptrdiff_t;
    using value_type = type;
    using pointer = type*;
    using reference = type&;

    BSTForwardConst_Iterator_Base(list_node_type* root)
    {
        pushAll(root);
    }

    iterator_type& operator++()
    {
        list_node_type* tmpNode = myStack.top();
        myStack.pop();
        pushAll(tmpNode->right);
        return *static_cast<iterator_type*>(this);
    }

    iterator_type operator++(int)
    {
        list_node_type* tmpNode = myStack.top();
        myStack.pop();
        pushAll(tmpNode->right);
        return iterator_type(tmpNode);
    }



    const type& operator*() const { return myStack.top()->data; }
    bool operator !=(const iterator_type& other) const { return myStack != other.myStack; }
    bool operator ==(const iterator_type& other) const { return myStack == other.myStack; }

    const std::remove_pointer_t<type>* operator->()
    {
        if constexpr (std::is_pointer_v<type>)
        {
            return myStack.top();
        }
        else
        {
            return &myStack.top();
        }

    }

private:
    void pushAll(list_node_type* node)
    {
        while (node != nullptr)
        {
            myStack.push(node);
            node = node->left;
        }
    }

protected:
    std::stack<list_node_type*> myStack;
};


template <typename type, typename iterator_type, typename list_node_type>
struct BSTForwardIterator_Base : public BSTForwardConst_Iterator_Base<type, iterator_type, list_node_type>
{
public:
    using difference_type = BSTForwardConst_Iterator_Base<type, iterator_type, list_node_type>::difference_type;

    BSTForwardIterator_Base(list_node_type* ptr)
        :BSTForwardConst_Iterator_Base<type, iterator_type, list_node_type>{ ptr }
    { }

    type& operator*() const { return this->myStack.top()->data; }
    std::remove_pointer_t<type>* operator->()
    {
        if constexpr (std::is_pointer_v<type>)
        {
            return this->myStack.top();
        }
        else
        {
            return &this->myStack.top();
        }


    }

};
