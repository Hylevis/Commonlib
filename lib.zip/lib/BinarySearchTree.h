#pragma once
#include <iostream>
#include <stack>
#include "BSTForwardIterator.h"


template<class type>
class BinarySearchTree {
private:
    int m_Size = 0;
public:
    struct node 
    {
        type data;
        node* left;
        node* right;
        node* parent;

        node() = delete;

        node(type x, node* leftptr, node* rightptr, node* parentptr)
            :data(x)
            ,left(leftptr)
            ,right(rightptr)
            ,parent(parentptr)
        {
        }
        node(type x)
            :data(x)
            , left(nullptr)
            , right(nullptr)
            , parent(nullptr)
        {
        }
    };


private:

    node* root;

    node* makeEmpty(node* t)
    {
        if (t == nullptr)
            return nullptr;
        {
            makeEmpty(t->left);
            makeEmpty(t->right);
            delete t;
        }
        m_Size = 0;
        return nullptr;
    }

    node* Add(type x, node* t, node* parent)
    {
        if (t == nullptr)
        {
            t = new node(x, nullptr, nullptr, parent);
        }
        else if (x <= t->data)
        {
            t->left = Add(x, t->left, t);
        }
        else if (x > t->data)
        {
            t->right = Add(x, t->right, t);
        }
        return t;
    }

    node* findMin(node* t)
    {
        if (t == nullptr)
            return nullptr;
        else if (t->left == nullptr)
            return t;
        else
            return findMin(t->left);
    }

    node* findMax(node* t)
    {
        if (t == nullptr)
            return nullptr;
        else if (t->right == nullptr)
            return t;
        else
            return findMax(t->right);
    }

    node* remove(const type& x, node* t)
    {
        node* temp;
        if (t == nullptr)
        {
            return nullptr;
        }
        else if (x < t->data)
        {
            t->left = remove(x, t->left);
        }
        else if (x > t->data)
        {
            t->right = remove(x, t->right);
        }
        else if (t->left && t->right)
        {
            temp = findMin(t->right);
            t->data = temp->data;
            t->right = remove(t->data, t->right);
        }
        else
        {
            temp = t;
            if (t->left == nullptr)
            {
                t = t->right;
            }
            else if (t->right == nullptr)
            {
                t = t->left;
            }
            delete temp;
        }

        return t;
    }

    void inorder(node* t) 
    {
        if (t == nullptr)
            return;
        inorder(t->left);
        std::cout << t->data << " ";
        inorder(t->right);
    }

    node* find(node* t, type x)
    {
        if (t == nullptr)
        {
            return nullptr;
        }
        else if (x < t->data)
        {
            return find(t->left, x);
        }
        else if (x > t->data)
        {
            return find(t->right, x);
        }
        else
        {
            return t;
        }
    }

    void clearTree(node* node)
    {
        if (node != nullptr) {
            clearTree(node->left);
            clearTree(node->right);
            delete(node);
        }
    }

    void preOrderTraversal(node* c)
    {
        if (c != nullptr)
        {
            this->Add(c->data);
            preOrderTraversal(c->left);
            preOrderTraversal(c->right);
        }
    }

public:
    CONST_ITERATOR_DECLARATION(BSTForwardConst_Iterator_Base, type, node);
    ITERATOR_DECLARATION(BSTForwardIterator_Base, type, node);

    BinarySearchTree()
        : root(nullptr)
    {
    }
   
    BinarySearchTree(std::initializer_list<type> list)
    {
        for (const type& x : list)
        {
            this->Add(x);
        }
    }

    BinarySearchTree(const BinarySearchTree& other)
    {
       
        if (this != &other)
        {
            Clear();
            node* c = other.root;
            preOrderTraversal(c);
        }
        m_Size = other.m_Size;
    }
    ~BinarySearchTree()
    {
        root = makeEmpty(root);
    }

    void Add(const type& x) {
        root = Add(x, root, nullptr);
        m_Size++;
    }

    void remove(const type& x)
    {
        root = remove(x, root);
        m_Size--;
    }

    void display() 
    {
        inorder(root);
        std::cout << std::endl;
    }

    bool Exists(type x)
    {
        root = find(root, x);
        return root != nullptr;

    }

    void Clear()
    {
        root = makeEmpty(root);
    }

    node* GetRoot() { return root; }

    int size() { return m_Size; }
    int Size() { return m_Size; }
    bool IsEmpty() { return m_Size == 0; }

    const_iterator const cbegin() { return const_iterator(findMin(root)); }
    const_iterator const cend() { return const_iterator(nullptr); }

    BinarySearchTree& operator=(BinarySearchTree& other)
    {
        if (this != &other)
        {
            Clear();
            node* c = other.root;
            preOrderTraversal(c);
        }
        return *this;
        m_Size = other.size();
    }

};
