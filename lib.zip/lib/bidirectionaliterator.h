#pragma once
#include<iostream>






template <typename type, typename iterator_type, typename list_node_type>
struct BidirectionalConst_Iterator_Base
{

public:

    using iterator_category = std::bidirectional_iterator_tag;
    using difference_type = std::ptrdiff_t;
    using value_type = type;
    using pointer = type*;
    using reference = type&;

    BidirectionalConst_Iterator_Base(list_node_type* ptr)
        :m_ptr{ ptr }
    { }

    iterator_type& operator++()
    {
        m_ptr = m_ptr->m_Next;
        return *static_cast<iterator_type*>(this);
    }

    iterator_type operator++(int)
    {
        list_node_type* previous = m_ptr;
        m_ptr = m_ptr->m_Next;
        return iterator_type(previous);
    }

    iterator_type& operator--()
    {
        m_ptr = m_ptr->m_Previous;
        return *static_cast<iterator_type*>(this);
    }

    iterator_type& operator--(int)
    {
        list_node_type* previous = m_ptr;
        m_ptr = m_ptr->m_Previous;
        return iterator_type(previous);
    }

    const type& operator*() const { return m_ptr->m_Value; }
    bool operator !=(const iterator_type& other) const { return m_ptr != other.m_ptr; }
    bool operator ==(const iterator_type& other) const { return m_ptr == other.m_ptr; }

    const std::remove_pointer_t<type>* operator->()
    {
        if constexpr (std::is_pointer_v<type>)
        {
            return m_ptr->m_Value;
        }
        else
        {
            return &m_ptr->m_Value;
        }

    }

protected:
    list_node_type* m_ptr;
};



template <typename type, typename iterator_type, typename list_node_type>
struct BidirectionalIterator_Base : public BidirectionalConst_Iterator_Base<type, iterator_type, list_node_type>
{
public:
    using difference_type = BidirectionalConst_Iterator_Base<type, iterator_type, list_node_type>::difference_type;

    BidirectionalIterator_Base(list_node_type* ptr)
        :BidirectionalConst_Iterator_Base<type, iterator_type, list_node_type>{ ptr }
    { }

    type& operator*() const { return m_ptr->m_Value; }
    std::remove_pointer_t<type>* operator->()
    {
        if constexpr (std::is_pointer_v<type>)
        {
            return m_ptr->m_Value;
        }
        else
        {
            return &m_ptr->m_Value;
        }

    }
};


template <typename type, typename iterator_type, typename list_node_type>
struct BidirectionalConst_Reverse_Iterator_Base
{
public:

    using iterator_category = std::bidirectional_iterator_tag;
    using difference_type = std::ptrdiff_t;
    using value_type = type;
    using pointer = type*;
    using reference = type&;


    BidirectionalConst_Reverse_Iterator_Base(list_node_type* ptr)
        :m_ptr{ ptr }
    { }

    iterator_type& operator++()
    {
        m_ptr = m_ptr->m_Previous;
        return *static_cast<iterator_type*>(this);
    }

    iterator_type operator++(int)
    {
        list_node_type* previous = m_ptr;
        m_ptr = m_ptr->m_Previous;
        return iterator_type(previous);
    }

    iterator_type& operator--()
    {
        m_ptr = m_ptr->m_Next;
        return *static_cast<iterator_type*>(this);
    }

    iterator_type& operator--(int)
    {
        list_node_type* previous = m_ptr;
        m_ptr = m_ptr->m_Next;
        return iterator_type(previous);
    }

    const type& operator*() const { return m_ptr->m_Value; }
    bool operator !=(const iterator_type& other) const { return m_ptr != other.m_ptr; }
    bool operator ==(const iterator_type& other) const { return m_ptr == other.m_ptr; }

    const std::remove_pointer_t<type>* operator->()
    {
        if constexpr (std::is_pointer_v<type>)
        {
            return m_ptr->m_Value;
        }
        else
        {
            return &m_ptr->m_Value;
        }

    }

protected:
    list_node_type* m_ptr;
};



template <typename type, typename iterator_type, typename list_node_type>
struct BidirectionalReverse_Iterator_Base : public BidirectionalConst_Reverse_Iterator_Base<type, iterator_type, list_node_type>
{
public:
    using difference_type = BidirectionalConst_Reverse_Iterator_Base<type, iterator_type, list_node_type>::difference_type;

    BidirectionalReverse_Iterator_Base(list_node_type* ptr)
        :BidirectionalConst_Reverse_Iterator_Base<type, iterator_type, list_node_type>{ ptr }
    { }


    type& operator*() const { return m_ptr->m_Value; }
    std::remove_pointer_t<type>* operator->()
    {
        if constexpr (std::is_pointer_v<type>)
        {
            return m_ptr->m_Value;
        }
        else
        {
            return &m_ptr->m_Value;
        }

    }
};