#pragma once
#include <assert.h>
#include "randomaccessiterator.h"

// Example of a C Style array (allocated on the stack)
// int blah[4] = { 1, 23,4, 34 };
// Example of c++ style array (allocated on the stack)
//std::array<int, 4> blah3 = { 1 , 3, 324 , 4 };

// Example of heap allocated array. You should not be doing this for a static array!
// int* blah2 = new int();
template <typename type, unsigned int m_size>
class StaticArray 
{
private:
    using uint = unsigned int;
    type m_Array[m_size];
    uint m_CurrentSize = 0;

public:
    using uint = unsigned int;


public:
    CONST_ITERATOR_DECLARATION(RandomAccessConst_Iterator_Base, type);
    ITERATOR_DECLARATION(RandomAccessIterator_Base, type);
    CONST_REVERSE_ITERATOR_DECLARATION(RandomAccessConst_Reverse_Iterator_Base, type);
    REVERSE_ITERATOR_DECLARATION(RandomAccessReverse_Iterator_Base, type);
   
    iterator begin() { return iterator(&m_Array[0]); }
    iterator LastElement() { return iterator(&m_Array[m_CurrentSize - 1]); }
    const_iterator cbegin() const { return const_iterator(&m_Array[0]); }
    reverse_iterator rbegin() { return reverse_iterator(&m_Array[m_CurrentSize - 1]); }
    const_reverse_iterator crbegin() const { return const_reverse_iterator(&m_Array[m_CurrentSize - 1]); }

    iterator end() { return iterator(&m_Array[m_CurrentSize]); }
    const_iterator cend() const { return const_iterator(&m_Array[m_CurrentSize]); }
    reverse_iterator rend() { return reverse_iterator(&m_Array[-1]); }
    const_reverse_iterator crend() const { return const_reverse_iterator(&m_Array[m_CurrentSize - 1]); }
    
    StaticArray() {}
    // How can you implement this so that it accepts both an Array, StaticArray, and std::vector?
    template <typename type>
    StaticArray(const type& other)
    {

        for (int i = 0; i < m_size; i++)
        {
            m_Array[i] = other[i];
        }
    }
    StaticArray(std::initializer_list<type> list)
    {
        //m_Array = m_Array[list.size()];

        for (type x : list)
        {
            Add(x);
        }
    }
    ~StaticArray() {}

    uint Size() const { return m_CurrentSize; }
    uint size() const { return m_CurrentSize; }
    uint ReservedSize() const { return m_size; }

    type* GetBuffer() { return &m_Array; };

    const type& GetAt(uint index) const { return m_Array[index]; }
    type& GetAt(uint index) { return m_Array[index]; }

    void Add(const type& value)
    {
        assert(m_CurrentSize < m_size);//cannot add to a static array that is filled

        m_Array[m_CurrentSize] = value;
        m_CurrentSize++;
    }
    bool AddUnique(const type& value) 
    {
        for (uint i = 0; i < m_CurrentSize; i++)
        {
            if (m_Array[i] == value)
            {
                return false;
            }
        }
        Add(value);
        return true;
    }

    bool Insert(const type& value, uint index)
    {
        assert(m_CurrentSize + 1 <= m_size);// cannot add to a static array that is filled

        this->Add(value);
        for (uint i = m_CurrentSize - 1; i > index; i--)
        {
            std::swap(m_Array[i], m_Array[i - 1]);
        }
        return true;
    }
    iterator Insert(const type& value, iterator it)
    {
        assert(m_CurrentSize + 1 <= m_size);// cannot add to a static array that is filled

        this->Add(value);
        iterator itend = LastElement();
        for (iterator i = it; i != itend; ++i)
        {
            std::swap(*i, *itend);
        }
        return it++;



    }
    reverse_iterator Insert(const type& value, reverse_iterator it)
    {
        assert(m_CurrentSize + 1 <= m_size);


        this->Add(value);
        reverse_iterator itend = rbegin();
        for (reverse_iterator i = it; i != itend; --i)
        {
            std::swap(*i, *itend);
        }
        return it++;


    }
                
    bool Remove(type value) 
    {
        int index = -1;
        for (uint i = 0; i < m_CurrentSize; i++)
        {
            if (m_Array[i] == value)
            {
                index = i;
            }
        }

        return RemoveAt(index);
    }
    bool RemoveAt(uint index) 
    {
        for (unsigned int i = index; i < m_CurrentSize - 1; i++)
        {
            std::swap(m_Array[i], m_Array[i + 1]);
        }

        if (m_CurrentSize != 0)
        {
            m_CurrentSize--;
            return true;
        }
        else
        {
            return false;
        }
    }
    iterator RemoveAt(iterator it) 
    {
        iterator itend = LastElement();
        if (itend == it)
        {
            m_CurrentSize--;
            return end();
        }
        else
        {
            for (iterator i = itend; i != it; --i)
            {
                std::swap(*i, *it);
            }
            m_CurrentSize--;
            return it;
        }
    }
    reverse_iterator RemoveAt(reverse_iterator it) 
    {
        reverse_iterator itend = rbegin();
        if (itend == it)
        {
            m_CurrentSize--;
            return ++itend;
        }
        else
        {
            for (reverse_iterator i = rbegin(); i != it; ++i)
            {
                std::swap(*i, *it);
            }
            m_CurrentSize--;
            return it;
        }
    }

    bool IsValidIndex(uint index) const noexcept { return (index <= m_size && index >= 0); }
    const type& operator[](uint index) const { return GetAt(index); }
    type& operator[](uint index) { return GetAt(index); }

    // How can you implement this so that it accepts both an Array, StaticArray, and std::vector?
    template <typename type>
    StaticArray<type, m_size>& operator=( const type& other)
    {
        if (this == &other)
            return *this;
        if (other.size() <= m_size)
        {
            for (int i = 0; i < m_size; i++)
            {
                m_Array[i] = other[i];
            }
        }
        return *this;
    }
};