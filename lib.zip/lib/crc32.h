#pragma once
#include <cstdint>
#include <string_view>

namespace CRC32
{
template<typename T>
struct TypeName 
{
    constexpr static std::string_view GetFullName() {
#if defined(__clang__) || defined(__GNUC__)
        return __PRETTY_FUNCTION__;
#elif defined(_MSC_VER)
        return __FUNCSIG__;
#else
#error "Unsupported compiler"
#endif
    }
    constexpr static std::string_view GetName() {
        size_t prefix_len = TypeName<void>::GetFullName().find("void");
        size_t multiple = TypeName<void>::GetFullName().size() - TypeName<int>::GetFullName().size();
        size_t dummy_len = TypeName<void>::GetFullName().size() - 4 * multiple;
        size_t target_len = (GetFullName().size() - dummy_len) / multiple;
        std::string_view rv = GetFullName().substr(prefix_len, target_len);
        if (rv.rfind(' ') == rv.npos)
            return rv;
        return rv.substr(rv.rfind(' ') + 1);
    }

    using type = T;
    constexpr static std::string_view value = GetName();
};

using TypeId = uint32_t;

// Generate CRC lookup table
template <unsigned c, int k = 8>
struct CRC32TableBuilder : CRC32TableBuilder<((c & 1) ? 0xedb88320 : 0) ^ (c >> 1), k - 1> {};
template <unsigned c> struct CRC32TableBuilder<c, 0> { enum { value = c }; };

#define A(x) B(x) B(x + 128)
#define B(x) C(x) C(x +  64)
#define C(x) D(x) D(x +  32)
#define D(x) E(x) E(x +  16)
#define E(x) F(x) F(x +   8)
#define F(x) G(x) G(x +   4)
#define G(x) H(x) H(x +   2)
#define H(x) I(x) I(x +   1)
#define I(x) static_cast<uint32_t>(CRC32TableBuilder<x>::value),

static constexpr unsigned crc_table[] = { A(0) };

#undef A
#undef B
#undef C
#undef D
#undef E
#undef F
#undef G
#undef H
#undef I

// Constexpr implementation and helpers
constexpr uint32_t GenerateCRC32(const char* data) 
{
    uint32_t crc = ~0u;

    for (size_t i = 0; char c = data[i]; ++i)
    {
        crc = crc_table[(crc ^ c) & 0xFF] ^ (crc >> 8);
    }

    return ~crc;
}

} // END namespace CRC32

constexpr CRC32::TypeId CompileTimeCRC32(const char* str) 
{
    return CRC32::GenerateCRC32(str);
}

template<typename Class>
constexpr CRC32::TypeId CompileTimeCRC32() 
{
    constexpr std::string_view className = CRC32::TypeName<Class>::value;
    return CRC32::GenerateCRC32(className.data());
}
