#include <SFML/System/Clock.hpp>
#include <iostream>
#include <vector>
#include <string>
#include "sorts.h"
#include <lib/array.h>


using namespace std;

// Function to print an array
void printArray(std::vector<int>& dataSet)
{
    int i = 0;
    for (i = 0; i < dataSet.size(); i++)
    {
        std::cout << std::to_string(dataSet[i]) << std::endl;
    }
}
template <typename type>
void printArray(Array<type>& dataSet)
{
    for (unsigned int i = 0; i < dataSet.Size(); i++)
    {
        std::cout << std::to_string(dataSet[i]) << std::endl;
    }
}

int main()
{
    sf::Clock timer;
    srand(1500); // Seed the random so its the same every time

    std::vector<int> dataSet;
    for (int i = 0; i <= 1000; i++)
    {
        int temp = rand() % 100000;
        dataSet.push_back(temp);
        //std::cout << std::to_string(dataSet[i]) << std::endl;
    }
    Array<int> dataSet7;
    dataSet7.Reserve(1000);
    for (int i = 0; i <= 1000; i++)
    {
        int temp = rand() % 100000;
        dataSet7.Add(temp);
        //std::cout << std::to_string(dataSet[i]) << std::endl;
    }
    std::vector<int> dataSet2 = dataSet;
    std::vector<int> dataSet3 = dataSet;
    std::vector<int> dataSet4 = dataSet;
    std::vector<int> dataSet5 = dataSet;
    std::vector<int> dataSet6 = dataSet;
    timer.restart();
    bubbleSort(dataSet2);
    cout << "Bubble sort : " + to_string(timer.getElapsedTime().asSeconds()) << endl;

    printArray(dataSet2);

    timer.restart();
    selectionSort(dataSet3);
    printArray(dataSet3);
    cout << "Selection sort : " + to_string(timer.getElapsedTime().asSeconds()) << endl;

    timer.restart();
    insertionSort(dataSet4);
    printArray(dataSet4);
    cout << "Insertion sort : " + to_string(timer.getElapsedTime().asSeconds()) << endl;

    timer.restart();
    quickSort(dataSet7, 0, static_cast<int>(dataSet7.Size() - 1));
    printArray(dataSet7);
    cout << "quick sort : " + to_string(timer.getElapsedTime().asSeconds()) << endl;
    return 0;
}