#pragma once
#include <vector>
#include <lib/array.h>

template <typename type>
void bubbleSort(type& dataSet)
{
    // You can find the pseudo code here: https://en.wikipedia.org/wiki/Bubble_sort
    for (int i = 0; i < dataSet.size() - 1; i++)
    {
        for (int j = 0; j < dataSet.size() - i - 1; j++)
        {
            if (dataSet[j] > dataSet[j + 1])
            {
                std::swap(dataSet[j + 1], dataSet[j]);
            }
        }
    }

}

template <typename type>
void selectionSort(type& dataSet)
{
    // A good course for it:
    // https://www.khanacademy.org/computing/computer-science/algorithms/sorting-algorithms/a/selection-sort-pseudocode

    for (int i = 0; i < dataSet.size() - 1; i++)
    {
        int smallestIndex = i;
        for (int j = i + 1; j < dataSet.size(); j++)
        {
            if (dataSet[j] < dataSet[smallestIndex])
            {
                smallestIndex = j;
            }
        }
        if (smallestIndex != i)
        {
            std::swap(dataSet[smallestIndex], dataSet[i]);
        }
    }
}

template <typename type>
void insertionSort(type& dataSet)
{
    // A good course for it:
    // https://www.khanacademy.org/computing/computer-science/algorithms/insertion-sort/a/insertion-sort-pseudocode
    int key = -1;
    int j = -1;
    for (int i = 0; i < dataSet.size() - 1; i++)
    {
        key = dataSet[i];
        j = i - 1;

        while (j >= 0 && dataSet[j] > key)
        {
            dataSet[j + 1] = dataSet[j];
            j--;
        }
        dataSet[j + 1] = key;
    }
}

template <typename type>
void merge(type& dataSet, int left, int middle, int right)
{
    int i = left;
    int j = middle + 1;
    int k = left;

    std::vector<type> temp = dataSet;

    while (i <= middle && j <= right)
    {
        if (dataSet[i] <= dataSet[j])
        {
            temp[k] = dataSet[i];
            i++;
            k++;
        }
        else
        {
            temp[k] = dataSet[j];
            j++;
            k++;
        }
    }
    while (i <= middle)
    {
        temp[k] = dataSet[i];
        i++;
        k++;
    }
    while (j <= right)
    {
        temp[k] = dataSet[j];
        j++;
        k++;
    }
    for (int L = left; L <= right; L++)
    {
        dataSet[L] = temp[L];
    }
}

template <typename type>
int partition(type& dataSet, int start, int end)
{

    int pivot = dataSet[start];

    int count = 0;
    for (int i = start + 1; i <= end; i++)
    {
        if (dataSet[i] <= pivot)
        {
            count++;
        }
    }

    int pivotIndex = start + count;
    std::swap(dataSet[pivotIndex], dataSet[start]);


    int i = start;
    int j = end;

    while (i < pivotIndex && j > pivotIndex) {

        while (dataSet[i] <= pivot)
        {
            i++;
        }

        while (dataSet[j] > pivot)
        {
            j--;
        }

        if (i < pivotIndex && j > pivotIndex)
        {
            std::swap(dataSet[i++], dataSet[j--]);
        }
    }

    return pivotIndex;
}

template <typename type>
void quickSort(type& dataSet, int start, int end)
{
    // A good course for it:
    // https://www.khanacademy.org/computing/computer-science/algorithms/quick-sort/a/overview-of-quicksort

    if (start >= end)
        return;

    int p = partition(dataSet, start, end);

    quickSort(dataSet, start, p - 1);

    quickSort(dataSet, p + 1, end);
}


