#include "pch.h"
#include "CppUnitTest.h"
#include "lib/BinarySearchTree.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace BinarySearchTreeUnitTests
{
	TEST_CLASS(BinarySearchTreeUnitTests)
	{
	public:
		
		TEST_METHOD(Add)
		{
			BinarySearchTree<std::string> test;
			test.Add("a");
			BinarySearchTree<std::string>::node* testnode = test.GetRoot();
			Assert::AreEqual(testnode->data, std::string("a"));
			test.Add("b");
			test.Add("z");
			Assert::AreEqual(testnode->right->data, std::string("b"));
			Assert::AreEqual(testnode->right->right->data, std::string("z"));
			test.Add("x");
			Assert::AreEqual(testnode->right->right->left->data, std::string("x"));
		}

		TEST_METHOD(Remove)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d" };
			test.remove("a");
			BinarySearchTree<std::string>::node* testnode = test.GetRoot();
			Assert::AreEqual(testnode->data, std::string("b"));
			test.remove("c");
			Assert::AreEqual(testnode->right->data, std::string("d"));
		}

		TEST_METHOD(Exists)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d" };
			Assert::IsTrue(test.Exists(std::string("a")));
			Assert::IsFalse(test.Exists(std::string("z")));
		}
		TEST_METHOD(IsEmpty)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d" };
			Assert::IsFalse(test.IsEmpty());
			BinarySearchTree<std::string> test2;
			Assert::IsTrue(test2.IsEmpty());
		}
		TEST_METHOD(Clear)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d" };
			Assert::IsFalse(test.IsEmpty());
			test.Clear();
			Assert::IsTrue(test.IsEmpty());
		}
		TEST_METHOD(size)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d" };
			Assert::AreEqual(test.size(), 4);
			test.Clear();
			Assert::AreEqual(test.size(), 0);;
		}

		TEST_METHOD(Size)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d" };
			Assert::AreEqual(test.Size(), 4);
			test.Clear();
			Assert::AreEqual(test.Size(), 0);;
		}
	};

	TEST_CLASS(Constructors)
	{
		TEST_METHOD(Copy)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d" };
			BinarySearchTree<std::string> test2 = test;
			BinarySearchTree<std::string>::node* testnode = test2.GetRoot();
			Assert::AreEqual(testnode->data, std::string("a"));
			Assert::AreEqual(testnode->right->data, std::string("b"));
			Assert::AreEqual(testnode->right->right->data, std::string("c"));

		};

		TEST_METHOD(initializer_list)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d" };
			BinarySearchTree<std::string>::node* testnode = test.GetRoot();
			Assert::AreEqual(testnode->data, std::string("a"));
			Assert::AreEqual(testnode->right->data, std::string("b"));
			Assert::AreEqual(testnode->right->right->data, std::string("c"));

		};
	};

}
