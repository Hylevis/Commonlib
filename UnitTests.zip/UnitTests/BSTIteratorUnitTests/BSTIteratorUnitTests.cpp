#include "pch.h"
#include "CppUnitTest.h"
#include "lib/BinarySearchTree.h"


using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace BSTIteratorUnitTests
{
	TEST_CLASS(BSTIteratorUnitTests)
	{
	public:
		
		TEST_METHOD(PrePlusPlus)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d", "e", "f", "g"};
			auto it = test.cbegin();
			Assert::AreEqual(*it, std::string("a"));
			++it;
			Assert::AreEqual(*it, std::string("b"));
			++it;
			Assert::AreEqual(*it, std::string("c"));

		}
		TEST_METHOD(PostPlusPlus)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d", "e", "f", "g" };
			auto it = test.cbegin();
			Assert::AreEqual(*it, std::string("a"));
			it++;
			Assert::AreEqual(*it, std::string("b"));
			it++;
			Assert::AreEqual(*it, std::string("c"));

		}
		TEST_METHOD(NotEqual)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d", "e", "f", "g" };
			auto it = test.cbegin();
			auto it2 = test.cbegin();
			auto it3 = test.cend();
			Assert::IsFalse(it != it2);
			Assert::IsTrue(it != it3);
		}

		TEST_METHOD(EqualEqual)
		{
			BinarySearchTree<std::string> test{ "a", "b", "c", "d", "e", "f", "g" };
			auto it = test.cbegin();
			auto it2 = test.cbegin();
			auto it3 = test.cend();
			Assert::IsTrue(it == it2);
			Assert::IsFalse(it == it3);
		}
	};
}
