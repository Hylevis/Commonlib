#include "pch.h"
#include "CppUnitTest.h"
#include "lib\SinglyLinkedList.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace SinglyLinkedListUnitTests
{
	TEST_CLASS(Functions)
	{
	public:

		TEST_METHOD(Get)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			Assert::AreEqual(test.Get(3), std::string("d"));
			Assert::AreEqual(test.Get(0), std::string("a"));
			Assert::AreEqual(test.Get(1), std::string("b"));
			Assert::AreEqual(test.GetCapacity(), 4);
		}

		TEST_METHOD(AddBack)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			Assert::AreEqual(test.Size(), 3);
			Assert::AreEqual(test.GetCapacity(), 3);
			Assert::AreEqual(test.Get(2), std::string("c"));
			test.AddBack("d");
			Assert::AreEqual(test.Size(), 4);
			Assert::AreEqual(test.GetCapacity(), 4);
			Assert::AreEqual(test.Get(3), std::string("d"));
		}

		TEST_METHOD(AddFront)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddFront("a");
			test.AddFront("b");
			test.AddFront("c");
			Assert::AreEqual(test.Size(), 3);
			Assert::AreEqual(test.GetCapacity(), 3);
			Assert::AreEqual(test.Get(0), std::string("c"));
			test.AddFront("d");
			Assert::AreEqual(test.Size(), 4);
			Assert::AreEqual(test.GetCapacity(), 4);
			Assert::AreEqual(test.Get(0), std::string("d"));
			Assert::AreEqual(test.Get(1), std::string("c"));
			Assert::AreEqual(test.Get(2), std::string("b"));
			Assert::AreEqual(test.Get(3), std::string("a"));
		}
		TEST_METHOD(size)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			Assert::AreEqual(test.size(), 4);
			Assert::AreEqual(test.GetCapacity(), 4);
		}

		TEST_METHOD(Size)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			Assert::AreEqual(test.Size(), 4);
			Assert::AreEqual(test.GetCapacity(), 4);
		}

		TEST_METHOD(Resize)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			Assert::AreEqual(test.size(), 4);
			Assert::AreEqual(test.GetCapacity(), 4);
			test.Resize(2);
			Assert::AreEqual(test.size(), 2);
			Assert::AreEqual(test.GetCapacity(), 2);
			Assert::AreEqual(test.Get(0), std::string("a"));
			Assert::AreEqual(test.Get(1), std::string("b"));
			test.Resize(20);
			Assert::AreEqual(test.size(), 2);
			Assert::AreEqual(test.GetCapacity(), 20);
			Assert::AreEqual(test.Get(0), std::string("a"));
			Assert::AreEqual(test.Get(1), std::string("b"));

		}

		TEST_METHOD(GetCapacity)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			Assert::AreEqual(test.GetCapacity(), 4);
			Assert::AreEqual(test.size(), 4);
			test.Resize(2);
			Assert::AreEqual(test.GetCapacity(), 2);
			Assert::AreEqual(test.size(), 2);
			Assert::AreEqual(test.Get(0), std::string("a"));
			Assert::AreEqual(test.Get(1), std::string("b"));
			test.Resize(20);
			Assert::AreEqual(test.GetCapacity(), 20);
			Assert::AreEqual(test.Get(0), std::string("a"));
			Assert::AreEqual(test.Get(1), std::string("b"));

		}

		TEST_METHOD(Remove)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			Assert::AreEqual(test.Size(), 4);
			Assert::AreEqual(test.GetCapacity(), 4);
			test.Remove(1);
			Assert::AreEqual(test.Size(), 3);
			Assert::AreEqual(test.GetCapacity(), 3);
			Assert::AreEqual(test.Get(0), std::string("a"));
			Assert::AreEqual(test.Get(1), std::string("c"));
			Assert::AreEqual(test.Get(2), std::string("d"));
		}

		TEST_METHOD(Insert)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			Assert::AreEqual(test.Size(), 4);
			Assert::AreEqual(test.GetCapacity(), 4);
			test.insert(1, "z");
			Assert::AreEqual(test.Size(), 5);
			Assert::AreEqual(test.GetCapacity(), 5);
			Assert::AreEqual(test.Get(0), std::string("a"));
			Assert::AreEqual(test.Get(1), std::string("z"));
			Assert::AreEqual(test.Get(2), std::string("b"));
			Assert::AreEqual(test.Get(3), std::string("c"));
			Assert::AreEqual(test.Get(4), std::string("d"));
		}

		TEST_METHOD(Clear)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			Assert::AreEqual(test.Size(), 4);
			Assert::AreEqual(test.GetCapacity(), 4);
			test.Clear();
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
		}

		TEST_METHOD(PopFront)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddFront("a");
			test.AddFront("b");
			test.AddFront("c");
			Assert::AreEqual(test.Size(), 3);
			Assert::AreEqual(test.GetCapacity(), 3);
			Assert::AreEqual(test.Get(0), std::string("c"));
			test.PopFront();
			Assert::AreEqual(test.Size(), 2);
			Assert::AreEqual(test.GetCapacity(), 2);
			Assert::AreEqual(test.Get(0), std::string("b"));
			Assert::AreEqual(test.Get(1), std::string("a"));

		}

		TEST_METHOD(PopBack)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddFront("a");
			test.AddFront("b");
			test.AddFront("c");
			Assert::AreEqual(test.Size(), 3);
			Assert::AreEqual(test.GetCapacity(), 3);
			Assert::AreEqual(test.Get(0), std::string("c"));
			test.PopBack();
			Assert::AreEqual(test.Size(), 2);
			Assert::AreEqual(test.GetCapacity(), 2);
			Assert::AreEqual(test.Get(0), std::string("c"));
			Assert::AreEqual(test.Get(1), std::string("b"));

		}

		TEST_METHOD(IsEmpty)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			Assert::IsTrue(test.IsEmpty());
			test.AddFront("a");
			test.AddFront("b");
			test.AddFront("c");
			Assert::AreEqual(test.Size(), 3);
			Assert::AreEqual(test.GetCapacity(), 3);
			Assert::IsFalse(test.IsEmpty());

		}


	};

	TEST_CLASS(Operators)
	{
	public:

		TEST_METHOD(Equals)
		{
			SinglyLinkedList<std::string> test;
			Assert::AreEqual(test.Size(), 0);
			Assert::AreEqual(test.GetCapacity(), 0);
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			SinglyLinkedList<std::string> test2;
			test2 = test;
			Assert::AreEqual(test2.Size(), 4);
			Assert::AreEqual(test2.GetCapacity(), 4);
			Assert::AreEqual(test2.Get(0), std::string("a"));
			Assert::AreEqual(test2.Get(1), std::string("b"));
			Assert::AreEqual(test2.Get(2), std::string("c"));
			Assert::AreEqual(test2.Get(3), std::string("d"));

			Assert::AreEqual(test.Size(), 4);
			Assert::AreEqual(test.GetCapacity(), 4);
			Assert::AreEqual(test.Get(0), std::string("a"));
			Assert::AreEqual(test.Get(1), std::string("b"));
			Assert::AreEqual(test.Get(2), std::string("c"));
			Assert::AreEqual(test.Get(3), std::string("d"));

		}
	};

	TEST_CLASS(ForwardIterators)
	{
	public:

		TEST_METHOD(Insert)
		{
			SinglyLinkedList<std::string> test;
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");

			auto it = test.begin();
			test.insert(it, "z");
			
			Assert::AreEqual(test.Get(0), std::string("z"));

			it = ++test.begin();
			test.insert(it, "x");
			Assert::AreEqual(test.Get(1), std::string("x"));

			it = test.end();
			test.insert(it, "x");
			Assert::AreEqual(test.Get(6), std::string("x"));
		}

		TEST_METHOD(Remove)
		{
			SinglyLinkedList<std::string> test;
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			test.AddBack("e");
			test.AddBack("f");
			Assert::AreEqual(test.Size(), 6);
			auto it = test.begin();
			test.Remove(it);
			Assert::AreEqual(test.Size(), 5);
			Assert::AreEqual(test.Get(0), std::string("b"));

			it = ++test.begin();
			test.Remove(it);
			Assert::AreEqual(test.Size(), 4);
			Assert::AreEqual(test.Get(1), std::string("d"));

			it = test.LastElement();
			test.Remove(it);
			Assert::AreEqual(test.Size(), 3);
			Assert::AreEqual(test.Get(2), std::string("e"));

		}
	};

	TEST_CLASS(ForwardIteratorsOperators)
	{

		TEST_METHOD(EqualEqual)
		{
			SinglyLinkedList<std::string> test;
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			test.AddBack("e");
			test.AddBack("f");
			auto it = test.begin();
			auto it2 = test.LastElement();
			Assert::IsFalse(it == it2);
			it2 = it;
			Assert::IsTrue(it == it2);
		}

		TEST_METHOD(NotEqual)
		{
			SinglyLinkedList<std::string> test;
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			test.AddBack("e");
			test.AddBack("f");
			auto it = test.begin();
			auto it2 = test.LastElement();
			Assert::IsTrue(it != it2);
			it2 = it;
			Assert::IsFalse(it != it2);
		}

		TEST_METHOD(Arrow)
		{
			SinglyLinkedList<std::string> test;
			test.AddBack("a");
			test.AddBack("b");
			test.AddBack("c");
			test.AddBack("d");
			test.AddBack("e");
			test.AddBack("f");
			auto it = test.begin();
			Assert::AreEqual(it->data(), "a");

		}
	};
}
