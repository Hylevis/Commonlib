#include "pch.h"
#include "CppUnitTest.h"
#include <lib/array.h>


using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace ArrayUnitTests
{
	TEST_CLASS(Functions)
	{
	public:


		TEST_METHOD(GetAt)
		{


			Array<std::string> arrayString{ "0","1","2","3" };
			Assert::AreEqual(arrayString.GetAt(0), std::string("0"));


		};
		TEST_METHOD(Remove)
		{


			Array<std::string> arrayString{ "0","1","2","3","4","5" };
			Assert::AreEqual(arrayString.Size(), unsigned int(6));
			arrayString.Remove("0");
			Assert::AreEqual(arrayString.Size(), unsigned int(5));
			Assert::AreEqual(arrayString[0], std::string("1"));
			Assert::AreEqual(arrayString[1], std::string("2"));
			Assert::AreEqual(arrayString[2], std::string("3"));
			Assert::AreEqual(arrayString[3], std::string("4"));
			Assert::AreEqual(arrayString[4], std::string("5"));
			arrayString.Remove("2");
			Assert::AreEqual(arrayString.Size(), unsigned int(4));
			Assert::AreEqual(arrayString[0], std::string("1"));
			Assert::AreEqual(arrayString[1], std::string("3"));
			Assert::AreEqual(arrayString[2], std::string("4"));
			Assert::AreEqual(arrayString[3], std::string("5"));
			arrayString.Remove("5");
			Assert::AreEqual(arrayString.Size(), unsigned int(3));
			Assert::AreEqual(arrayString[0], std::string("1"));
			Assert::AreEqual(arrayString[1], std::string("3"));
			Assert::AreEqual(arrayString[2], std::string("4"));


		};
		TEST_METHOD(RemoveAt)
		{


			Array<std::string> arrayString{ "0","1","2","3","4","5" };
			arrayString.RemoveAt(0);
			Assert::AreEqual(arrayString[0], std::string("1"));
			Assert::AreEqual(arrayString[1], std::string("2"));
			Assert::AreEqual(arrayString[2], std::string("3"));
			Assert::AreEqual(arrayString[3], std::string("4"));
			Assert::AreEqual(arrayString[4], std::string("5"));
			arrayString.RemoveAt(2);
			Assert::AreEqual(arrayString[0], std::string("1"));
			Assert::AreEqual(arrayString[1], std::string("2"));
			Assert::AreEqual(arrayString[2], std::string("4"));
			Assert::AreEqual(arrayString[3], std::string("5"));
			arrayString.RemoveAt(3);
			Assert::AreEqual(arrayString[0], std::string("1"));
			Assert::AreEqual(arrayString[1], std::string("2"));
			Assert::AreEqual(arrayString[2], std::string("4"));


		};
		TEST_METHOD(Size)
		{


			Array<std::string> arrayString{ "0","1","2","3","4","5" };
			Assert::AreEqual(arrayString.Size(), unsigned int(6));

		};
		TEST_METHOD(Resize)
		{

			Array<std::string> arrayString{ "0","1","2","3","4","5" };
			arrayString.Resize(3);
			Assert::AreEqual(arrayString.Size(), unsigned int(3));
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("1"));
			Assert::AreEqual(arrayString[2], std::string("2"));

		};
		TEST_METHOD(Add)
		{

			Array<std::string> arrayString{ "0","1","2" };
			arrayString.Add("3");
			Assert::AreEqual(arrayString.Size(), unsigned int(4));
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("1"));
			Assert::AreEqual(arrayString[2], std::string("2"));
			Assert::AreEqual(arrayString[3], std::string("3"));
			arrayString.Reserve(5);
			arrayString.Add("4");
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("1"));
			Assert::AreEqual(arrayString[2], std::string("2"));
			Assert::AreEqual(arrayString[3], std::string("3"));
			Assert::AreEqual(arrayString[4], std::string("4"));

		};

		TEST_METHOD(AddUnique)
		{

			Array<std::string> arrayString{ "0","1","2" };
			arrayString.AddUnique("3");
			Assert::AreEqual(arrayString.Size(), unsigned int(4));
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("1"));
			Assert::AreEqual(arrayString[2], std::string("2"));
			Assert::AreEqual(arrayString[3], std::string("3"));

			arrayString.Reserve(5);
			arrayString.AddUnique("4");
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("1"));
			Assert::AreEqual(arrayString[2], std::string("2"));
			Assert::AreEqual(arrayString[3], std::string("3"));
			Assert::AreEqual(arrayString[4], std::string("4"));

			arrayString.AddUnique("3");
			Assert::AreEqual(arrayString.Size(), unsigned int(5));
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("1"));
			Assert::AreEqual(arrayString[2], std::string("2"));
			Assert::AreEqual(arrayString[3], std::string("3"));
			Assert::AreEqual(arrayString[4], std::string("4"));

		};
		TEST_METHOD(Insert)
		{

			Array<std::string> arrayString{ "0","1","2" };
			arrayString.Insert("3", 1);
			Assert::AreEqual(arrayString.Size(), unsigned int(4));
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("3"));
			Assert::AreEqual(arrayString[2], std::string("1"));
			Assert::AreEqual(arrayString[3], std::string("2"));
			arrayString.Insert("4", 4);
			Assert::AreEqual(arrayString.Size(), unsigned int(5));
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("3"));
			Assert::AreEqual(arrayString[2], std::string("1"));
			Assert::AreEqual(arrayString[3], std::string("2"));
			Assert::AreEqual(arrayString[4], std::string("4"));
			arrayString.Insert("-1", 0);
			Assert::AreEqual(arrayString.Size(), unsigned int(6));
			Assert::AreEqual(arrayString[0], std::string("-1"));
			Assert::AreEqual(arrayString[1], std::string("0"));
			Assert::AreEqual(arrayString[2], std::string("3"));
			Assert::AreEqual(arrayString[3], std::string("1"));
			Assert::AreEqual(arrayString[4], std::string("2"));
			Assert::AreEqual(arrayString[5], std::string("4"));
			arrayString.Reserve(6);
			arrayString.Insert("5", 6);
			Assert::AreEqual(arrayString[0], std::string("-1"));
			Assert::AreEqual(arrayString[1], std::string("0"));
			Assert::AreEqual(arrayString[2], std::string("3"));
			Assert::AreEqual(arrayString[3], std::string("1"));
			Assert::AreEqual(arrayString[4], std::string("2"));
			Assert::AreEqual(arrayString[5], std::string("4"));
			Assert::AreEqual(arrayString[6], std::string("5"));

		};

		TEST_METHOD(IsEmpty)
		{

			Array<std::string> falseArrayString{ "0","1","2" };
			Assert::IsFalse(falseArrayString.IsEmpty());

			Array<std::string> trueArrayString{};
			Assert::IsTrue(trueArrayString.IsEmpty());
		};
		TEST_METHOD(IsValidIndex)
		{

			Array<std::string> ArrayString{ "0","1","2" };
			Assert::IsFalse(ArrayString.IsValidIndex(5));
			Assert::IsFalse(ArrayString.IsValidIndex(-1));
			Assert::IsFalse(ArrayString.IsValidIndex(4));

			Assert::IsTrue(ArrayString.IsValidIndex(0));
			Assert::IsTrue(ArrayString.IsValidIndex(1));
			Assert::IsTrue(ArrayString.IsValidIndex(2));
		};

		TEST_METHOD(Reserve)
		{
			Array<std::string> arrayString{ "0","1","2" };
			arrayString.Reserve(10);
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("1"));
			Assert::AreEqual(arrayString[2], std::string("2"));
			Assert::IsTrue(arrayString.IsValidIndex(2));
			Assert::IsTrue(arrayString.IsValidIndex(5));
			Assert::IsTrue(arrayString.IsValidIndex(7));
			Assert::IsFalse(arrayString.IsValidIndex(11));
		}

		TEST_METHOD(GetAvailableSpace)
		{

			Array<std::string> arrayString{ "0","1","2" };
			arrayString.Reserve(10);
			Assert::AreEqual(arrayString.GetAvailableSpace(), static_cast<unsigned int>(7));
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("1"));
			Assert::AreEqual(arrayString[2], std::string("2"));

		};

		TEST_METHOD(Clear)
		{

			Array<std::string> arrayString{ "0","1","2" };
			arrayString.Clear();
			Assert::AreEqual(arrayString.Size(), static_cast<unsigned int>(0));

		};

	};

	TEST_CLASS(Operators)
	{
		TEST_METHOD(Star)
		{
			Array<std::string> arrayString{ "0","1","2","3" };
			Assert::AreEqual(*arrayString.begin(), std::string("0"));
		};
		TEST_METHOD(EqualEqual)
		{
			Array<std::string> arrayString{ "0","1","2","3" };
			Array<std::string> trueArrayString{ "0","1","2","3" };
			Array<std::string> falseArrayString{ "0","1","2" };
			Assert::IsTrue(arrayString == trueArrayString);
			Assert::IsFalse(arrayString == falseArrayString);
		};

		TEST_METHOD(Bracket)
		{
			Array<std::string> arrayString{ "0","1","2","3" };
			Assert::AreEqual(arrayString[0], std::string("0"));
			Assert::AreEqual(arrayString[1], std::string("1"));
			Assert::AreEqual(arrayString[2], std::string("2"));
			Assert::AreEqual(arrayString[3], std::string("3"));

			Assert::AreNotEqual(arrayString[0], std::string("1"));
			Assert::AreNotEqual(arrayString[1], std::string("2"));
			Assert::AreNotEqual(arrayString[2], std::string("3"));
			Assert::AreNotEqual(arrayString[3], std::string("4"));
		};
		TEST_METHOD(Equal)
		{
			Array<std::string> arrayString{ "0","1","2","3" };
			Array<std::string> newarrayString{ "6","2" };
			newarrayString = arrayString;
			Assert::AreEqual(newarrayString.size(), arrayString.size());
			Assert::AreEqual(newarrayString.GetAvailableSpace(), arrayString.GetAvailableSpace());
			Assert::AreEqual(newarrayString[0], std::string("0"));
			Assert::AreEqual(newarrayString[1], std::string("1"));
			Assert::AreEqual(newarrayString[2], std::string("2"));
			Assert::AreEqual(newarrayString[3], std::string("3"));

		};
	};

	TEST_CLASS(Constructors)
	{
		TEST_METHOD(CopyConstructor)
		{
			Array<std::string> arrayString{ "0","1","2","3" };
			Array<std::string> newarrayString = arrayString;
			Assert::AreEqual(newarrayString.size(), arrayString.size());
			Assert::AreEqual(newarrayString.GetAvailableSpace(), arrayString.GetAvailableSpace());
			Assert::AreEqual(newarrayString[0], std::string("0"));
			Assert::AreEqual(newarrayString[1], std::string("1"));
			Assert::AreEqual(newarrayString[2], std::string("2"));
			Assert::AreEqual(newarrayString[3], std::string("3"));

		};
	};

	TEST_CLASS(IteratorFunctions)
	{
		TEST_METHOD(ItInsert)
		{


			Array<std::string> arrayString{ "0","1","2","3" };
			arrayString.Reserve(50);
			auto it = arrayString.begin();
			arrayString.Insert("-1", it);
			Assert::AreEqual(arrayString[0], std::string("-1"));

			Array<std::string> newArrayString{ "0","1","2","3" };
			auto it2 = newArrayString.begin();
			newArrayString.Insert("-1", it2);
			Assert::AreEqual(newArrayString[0], std::string("-1"));


		};

		TEST_METHOD(ItRemoveAt)
		{


			Array<std::string> arrayString{ "0","1","2","3" };
			arrayString.Reserve(50);
			auto it = arrayString.begin();
			Assert::AreEqual(arrayString.size(), static_cast<unsigned int>(4));
			arrayString.RemoveAt(it);
			Assert::AreEqual(arrayString[0], std::string("1"));
			Assert::AreEqual(arrayString.size(), static_cast<unsigned int>(3));

			Array<std::string> newArrayString{ "0","1","2","3" };
			Assert::AreEqual(newArrayString.size(), static_cast<unsigned int>(4));
			auto it2 = newArrayString.LastElement();
			newArrayString.RemoveAt(it2);
			Assert::AreEqual(newArrayString.size(), static_cast<unsigned int>(3));

			Array<std::string> newerArrayString{ "0","1","2","3" };
			Assert::AreEqual(newerArrayString.size(), static_cast<unsigned int>(4));
			auto it3 = ++newerArrayString.begin();
			newerArrayString.RemoveAt(it3);
			Assert::AreEqual(newerArrayString[1], std::string("2"));
			Assert::AreEqual(newerArrayString.size(), static_cast<unsigned int>(3));


		};
	};

	TEST_CLASS(ReverseIteratorFunctions)
	{
		TEST_METHOD(ReverseItInsert)
		{


			Array<std::string> arrayString{ "0","1","2","3" };
			auto it = arrayString.rbegin();
			arrayString.Insert("-1", it);
			Assert::AreEqual(arrayString[3], std::string("-1"));

			Array<std::string> newarrayString{ "0","1","2","3" };
			newarrayString.Reserve(50);
			auto it2 = newarrayString.rbegin();
			newarrayString.Insert("-1", it2);
			Assert::AreEqual(newarrayString[3], std::string("-1"));


		};

		TEST_METHOD(ReverseItRemoveAt)
		{


			Array<std::string> arrayString{ "0","1","2","3" };
			arrayString.Reserve(50);
			auto it = arrayString.begin();
			Assert::AreEqual(arrayString.size(), static_cast<unsigned int>(4));
			arrayString.RemoveAt(it);
			Assert::AreEqual(arrayString[0], std::string("1"));
			Assert::AreEqual(arrayString.size(), static_cast<unsigned int>(3));

			Array<std::string> newArrayString{ "0","1","2","3" };
			Assert::AreEqual(newArrayString.size(), static_cast<unsigned int>(4));
			auto it2 = newArrayString.LastElement();
			newArrayString.RemoveAt(it2);
			Assert::AreEqual(newArrayString.size(), static_cast<unsigned int>(3));

			Array<std::string> newerArrayString{ "0","1","2","3" };
			Assert::AreEqual(newerArrayString.size(), static_cast<unsigned int>(4));
			auto it3 = ++newerArrayString.begin();
			newerArrayString.RemoveAt(it3);
			Assert::AreEqual(newerArrayString[1], std::string("2"));
			Assert::AreEqual(newerArrayString.size(), static_cast<unsigned int>(3));


		};
	};
}
