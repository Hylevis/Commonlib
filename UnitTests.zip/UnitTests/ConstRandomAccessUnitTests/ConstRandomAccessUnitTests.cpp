#include "pch.h"
#include "CppUnitTest.h"
#include "lib/randomaccessiterator.h"
#include "lib/array.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace ConstRandomAccessIteratorUnitTests
{
	struct Random_Access_Const_Iterator : public RandomAccessConst_Iterator_Base<std::string, Random_Access_Const_Iterator>
	{
		Random_Access_Const_Iterator(std::string* ptr)
			:RandomAccessConst_Iterator_Base < std::string, Random_Access_Const_Iterator>{ ptr }
		{ }
	};

	struct iterator : public RandomAccessIterator_Base<std::string, iterator>
	{
		iterator(std::string* ptr)
			:RandomAccessIterator_Base<std::string, iterator>{ ptr }
		{ }
	};
	TEST_CLASS(Operators)
	{
	public:

		TEST_METHOD(PrefixPlusPlus)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[0]);
			Assert::AreEqual(*constIT, std::string("0"));
			++constIT;
			Assert::AreEqual(*constIT, std::string("1"));
			++constIT;
			Assert::AreEqual(*constIT, std::string("2"));
			++constIT;
			Assert::AreEqual(*constIT, std::string("3"));
		}
		TEST_METHOD(PostfixPlusPlus)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[0]);
			Assert::AreEqual(*constIT, std::string("0"));
			constIT++;
			Assert::AreEqual(*constIT, std::string("1"));
			constIT++;
			Assert::AreEqual(*constIT, std::string("2"));
			constIT++;
			Assert::AreEqual(*constIT, std::string("3"));
		}
		TEST_METHOD(PrefixMinusMinus)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[3]);
			Assert::AreEqual(*constIT, std::string("3"));
			--constIT;
			Assert::AreEqual(*constIT, std::string("2"));
			--constIT;
			Assert::AreEqual(*constIT, std::string("1"));
			--constIT;
			Assert::AreEqual(*constIT, std::string("0"));
		}
		TEST_METHOD(PostfixMinusMinus)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[3]);
			Assert::AreEqual(*constIT, std::string("3"));
			constIT--;
			Assert::AreEqual(*constIT, std::string("2"));
			constIT--;
			Assert::AreEqual(*constIT, std::string("1"));
			constIT--;
			Assert::AreEqual(*constIT, std::string("0"));
		}
		TEST_METHOD(EqualEqual)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[3]);
			Random_Access_Const_Iterator constIT2 = Random_Access_Const_Iterator(&arrayString[3]);
			Assert::IsTrue(constIT == constIT2);
			constIT2--;
			Assert::IsFalse(constIT == constIT2);
		}
		TEST_METHOD(NotEqual)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[3]);
			Random_Access_Const_Iterator constIT2 = Random_Access_Const_Iterator(&arrayString[3]);
			Assert::IsFalse(constIT != constIT2);
			constIT2--;
			Assert::IsTrue(constIT != constIT2);
		}
		TEST_METHOD(Plus)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[0]);
			constIT = constIT + 2;
			Assert::AreEqual(*constIT, std::string("2"));
			constIT = constIT + 1;
			Assert::AreEqual(*constIT, std::string("3"));
		}
		TEST_METHOD(PlusEquals)
		{
			Array<std::string> arrayString{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[0]);
			constIT += 2;
			Assert::AreEqual(*constIT, std::string("2"));
			constIT += 1;
			Assert::AreEqual(*constIT, std::string("3"));
		}
		TEST_METHOD(Minus)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[3]);
			constIT = constIT - 2;
			Assert::AreEqual(*constIT, std::string("1"));
			constIT = constIT - 1;
			Assert::AreEqual(*constIT, std::string("0"));
		}
		TEST_METHOD(MinusEquals)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };;
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[3]);
			constIT -= 2;
			Assert::AreEqual(*constIT, std::string("1"));
			constIT -= 1;
			Assert::AreEqual(*constIT, std::string("0"));
		}
		TEST_METHOD(LessThan)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[0]);
			Random_Access_Const_Iterator constIT2 = Random_Access_Const_Iterator(&arrayString[1]);

			Assert::IsTrue(constIT < constIT2);
			constIT = Random_Access_Const_Iterator(&arrayString[2]);
			Assert::IsTrue(constIT2 < constIT);
		}
		TEST_METHOD(GreaterThan)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[0]);
			Random_Access_Const_Iterator constIT2 = Random_Access_Const_Iterator(&arrayString[1]);

			Assert::IsTrue(constIT2 > constIT);
			constIT = Random_Access_Const_Iterator(&arrayString[2]);
			Assert::IsTrue(constIT > constIT2);
		}
		TEST_METHOD(LessThanOrEqualTo)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[0]);
			Random_Access_Const_Iterator constIT2 = Random_Access_Const_Iterator(&arrayString[1]);

			Assert::IsTrue(constIT <= constIT2);
			constIT = Random_Access_Const_Iterator(&arrayString[2]);
			Assert::IsTrue(constIT2 <= constIT);
			constIT = Random_Access_Const_Iterator(&arrayString[1]);
			Assert::IsTrue(constIT2 <= constIT);
		}
		TEST_METHOD(GreaterThanOrEqualTo)
		{
			std::string* arrayString = new std::string[4]{ "0","1","2","3" };
			Random_Access_Const_Iterator constIT = Random_Access_Const_Iterator(&arrayString[0]);
			Random_Access_Const_Iterator constIT2 = Random_Access_Const_Iterator(&arrayString[1]);

			Assert::IsTrue(constIT2 >= constIT);
			constIT = Random_Access_Const_Iterator(&arrayString[2]);
			Assert::IsTrue(constIT >= constIT2);
			constIT = Random_Access_Const_Iterator(&arrayString[1]);
			Assert::IsTrue(constIT >= constIT2);
		}
		TEST_METHOD(Brackets)
		{

			std::string* arrayString = new std::string[4]{ "0","1","2","3" };

			auto constIT = Random_Access_Const_Iterator(&arrayString[0]);
			Assert::AreEqual(constIT[2], std::string("2"));

			constIT = Random_Access_Const_Iterator(&arrayString[2]);
			Assert::AreEqual(constIT[1], std::string("3"));
		}
		TEST_METHOD(Star)
		{

			std::string* arrayString = new std::string[4]{ "0","1","2","3" };

			auto constIT = Random_Access_Const_Iterator(&arrayString[0]);
			Assert::AreEqual(*constIT, std::string("0"));

			constIT = Random_Access_Const_Iterator(&arrayString[2]);
			Assert::AreEqual(*constIT, std::string("2"));
		}
		TEST_METHOD(Arrow)
		{

			std::string* arrayString = new std::string[4]{ "0","1","2","3" };

			auto constIT = Random_Access_Const_Iterator(&arrayString[0]);
			Assert::AreEqual(constIT->size(), size_t(1));
		}


	};

	TEST_CLASS(DynamicIterators)
	{
		TEST_METHOD(Brackets)
		{

			std::string* arrayString = new std::string[4]{ "0","1","2","3" };

			auto constIT = iterator(&arrayString[0]);
			Assert::AreEqual(constIT[2], std::string("2"));

			constIT = iterator(&arrayString[2]);
			Assert::AreEqual(constIT[1], std::string("3"));
		}
		TEST_METHOD(Star)
		{

			std::string* arrayString = new std::string[4]{ "0","1","2","3" };

			auto constIT = iterator(&arrayString[0]);
			Assert::AreEqual(*constIT, std::string("0"));

			constIT = iterator(&arrayString[2]);
			Assert::AreEqual(*constIT, std::string("2"));
		}
		TEST_METHOD(Arrow)
		{

			std::string* arrayString = new std::string[4]{ "0","1","2","3" };

			auto constIT = iterator(&arrayString[0]);
			Assert::AreEqual(constIT->size(), size_t(1));
		}

	};
}
